# Changelog

All notable changes to this project are documented in this file.
The format loosely follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [1.4.0] - 2026-07-10

### Added
- **`kinetics.kth_full()`**: the full KTH kinetic triplet -- Eₐ(α),
  pre-exponential factor A(α), and the experimental reaction model
  f(α) -- via Malek's method (thesis, Chapter VII, §VII.4.1.3).
  - 13 candidate theoretical models (`kinetics.KTH_CANDIDATE_MODELS`):
    reaction order (F0-F3), geometric contraction (R2-R3), diffusion
    (D1-D4), and Avrami-Erofeev nucleation-and-growth (A2-A4).
  - Model identification compares experimental, normalised y(α)/z(α)
    curves against each candidate's theoretical f(α) / f(α)·g(α)
    curves (the standard "master plot" shape-equivalence), and
    explicitly returns `"unknown"` when the best match is either poor
    or too close to the runner-up to trust -- rather than force-fitting
    a model onto ambiguous data. Confirmed on the bundled real sample
    dataset, which legitimately identifies as `"unknown"` (its two best
    candidates differ by under 5%).
  - `kinetics.average_ea`-style outputs for `A(α)` and `f(α)`, plus
    `model_scores`, `y_alpha`/`z_alpha` (experimental) and
    `y_theory`/`z_theory` (identified model's own curves, for plotting).
- **GUI**: a "KTH mode" dropdown ("Eₐ only" / "Full triplet (A, f(α),
  model)"); a new **KTH Model** tab plotting the y(α)/z(α) diagnostic
  curves against the identified model; `KTH_A`/`KTH_f(α)` columns in
  the Results Table.
- **Exporter**: `KTH_A`/`KTH_f_alpha` columns in `Ea_data.txt` and
  `Ea_results.xlsx` (plus a comment line / dedicated `KTH_Model` sheet
  naming the identified model and its match scores), and
  `KTH_model_plot.png/.svg/.pdf` alongside the main graph, whenever
  KTH was run in "Full triplet" mode.
- `logging.debug()` calls throughout model identification (candidate
  scores, ambiguity decisions) via the existing `isokinetics.kinetics`
  logger.
- 24 new tests: ground-truth validation against *two* different
  synthetic datasets (F1 and D3, generated from genuinely different
  reaction models, guarding against a classifier that only ever guesses
  one answer), A(α)/ln(A) recovery, the `"unknown"` fallback on
  non-physical data, GUI full-triplet-mode integration, and exporter
  integration.

### Fixed (found during validation, before shipping)
- **z(α) formula was missing a factor.** A literal reading of
  `z(α) = p(x)·(dα/dt)·(T/β)` -- as commonly abbreviated, including in
  the source thesis -- is *not* proportional to the theoretical
  `f(α)·g(α)` master-plot function; deriving it from first principles
  shows an additional `x·exp(x)` factor is required
  (`z(α) = (dα/dt)·(T/β)·x·exp(x)·p(x)`). Without this fix, model
  identification confidently picked the *wrong* model on synthetic data
  with a known ground truth (e.g. D1 instead of F1). Caught by
  validating against synthetic data before integrating, exactly as with
  the earlier Vyazovkin fix.
- **`p(x)` (temperature integral) computed by direct numerical
  integration**, not the closed-form Senum-Yang-style rational
  approximation as originally specified: a commonly-seen version of
  that approximation (`exp(-x)/x^2` tacked onto the rational prefactor)
  has the wrong asymptotic power of `x` for large `x`, and was found to
  make model identification unreliable. Numerical integration
  (trapezoidal rule, `isokinetics.kinetics._temperature_integral_p`)
  sidesteps the ambiguity and was checked against the exact closed form
  (`p(x) = e^-x/x - E1(x)`) to within 1e-5 relative error during
  development.
- `_identify_model`'s best-model selection now explicitly filters out
  non-finite scores before ranking (Python's `min()` does not reliably
  skip `NaN` values, which could otherwise select a spurious "best"
  model).

## [1.3.0] - 2026-07-09

### Added
- **KTH method** (`kinetics.kth`): a sixth isoconversional method,
  original to the accompanying thesis (Chapter VII), named after its
  authors' initials. Structurally a differential method like Friedman,
  but uses a discrete-step reaction rate `(α_{i+1}-α_i)/Δt_i` over each
  interval on the alpha grid, paired with the mean temperature over
  that interval, rather than an instantaneous derivative at a single
  point. The time step is recovered from the temperature step under
  the linear-heating assumption (no explicit time column required).
  Registered in `kinetics.METHODS`, added to the GUI's method
  checkboxes (`gui.METHOD_NAMES`), and given its own colour/marker in
  `plotter.py` (pink/magenta, "x").
- Validated the same way as every other method here: recovers a known
  150 kJ/mol ground-truth activation energy to within 5% on synthetic
  data (`tests/test_kinetics.py`), plus dedicated tests for its
  boundary handling (the last alpha point, which has no "next" point to
  step to) and its minimum-valid-points requirement (returns NaN with
  fewer than 3 valid heating-rate pairs, per the method's own
  specification -- stricter than the 2-point minimum used by the other
  methods here).
- Added `logging` calls (`isokinetics.kinetics` logger) inside `kth()`
  at DEBUG level, to aid debugging when points are skipped.

## [1.2.0] - 2026-07-08

### Fixed
- **Stray console errors on window close.** Closing the main window
  (or the splash screen) while any Tk `after` callback was still
  scheduled -- our own progress-bar updates, the splash screen's
  safety-net timer, or customtkinter's own internal DPI-scaling /
  appearance-mode polling loops (`ScalingTracker.check_dpi_scaling`,
  `AppearanceModeTracker.update`, both of which reschedule themselves
  every ~100ms for the life of the window) -- could print errors like:
  ```
  invalid command name "...check_dpi_scaling"
    while executing
  "...check_dpi_scaling"
    ("after" script)
  ```
  after the widgets they referenced were destroyed. Root-caused and
  fixed with a new `isokinetics._tk_utils.cancel_all_pending_after_callbacks()`
  helper (queries Tcl's `after info` and cancels every pending id, ours
  and customtkinter's alike), called from both `SplashScreen.destroy()`
  and `KineticsApp`'s new `_shutdown()` sequence before the widget
  hierarchy is torn down. Verified via a subprocess-based regression
  test suite (`tests/test_shutdown_regression.py`) that asserts zero
  such errors across closing at 9 different timing offsets, including
  mid-computation.
- **Background analysis thread now stops cleanly on close.**
  `KineticsApp` gained an `_alive` flag (false as soon as shutdown
  begins) and a `threading.Event` `_stop_event`. The analysis worker
  thread checks `_stop_event` between and during method computations
  and abandons immediately (without touching any widget) if the window
  is closing; `_update_progress`/`_on_analysis_done` additionally check
  `_alive` as a second guard against an already-in-flight callback.
  `_shutdown()` signals the stop event and joins the (daemon) thread
  with a short timeout before destroying the window.
- **`destroy()` is now idempotent** on both `KineticsApp` and
  `SplashScreen`. `tkinter.Tk.destroy()` itself is *not* safe to call
  twice (raises `TclError: can't invoke "destroy" command: application
  has been destroyed` on the second call); both classes now guard
  against this so tests, external callers, or Tkinter's own teardown
  calling `destroy()` more than once can never raise.

## [1.1.0] - 2026-07-08

### Added
- Branded splash screen (`isokinetics.splash`) shown on startup: a
  frameless, centered, dark-themed window with a small vector logo, a
  determinate progress bar tied to real initialization stages (NumPy /
  pandas, Matplotlib's Tk backend, UI construction), and an author
  credit ("Oukil khaled ibn el-walid").
- `run.py`: a root-level convenience launcher for running the app
  straight from a source checkout without installing the package
  first (`python run.py`).
- `tests/test_splash_smoke.py` and `tests/test_main_entrypoint.py`.

### Fixed
- **NumPy / Python 3.13 install failure.** `requirements.txt` pinned
  `numpy==1.26.4`, which has no pre-built wheel for Python 3.13 (NumPy
  only gained 3.13 wheels starting at 2.1.0), causing pip to attempt a
  from-source build that fails without a C/C++ compiler installed.
  Re-pinned to `numpy==2.1.3`, verified compatible with the existing
  `pandas==2.2.3` / `matplotlib==3.9.2` pins (full test suite re-run
  against this exact combination).
- **Confusing relative-import error when running `main.py` directly.**
  `python src/isokinetics/main.py` cannot work because relative imports
  (`from .splash import ...`) require the file to be loaded as part of
  its package. `main()` now detects this case (`__package__` is empty)
  and prints clear, actionable instructions instead of surfacing the
  raw `ImportError: attempted relative import with no known parent
  package`.
- Fixed a latent race condition in the splash screen's background
  loading thread: `Tk.after()` calls issued from a worker thread are
  only valid once the Tk main loop is actually running. The worker
  thread is now started via an `after()` callback itself (guaranteeing
  the main loop has started first) and a 20-second safety-net timer
  ensures the app always proceeds to the main window even if a startup
  stage raises an unexpected exception.

## [1.0.0] - 2026-07-07

### Added
- Initial public release.
- Data loading/validation for text (space/tab/comma/semicolon-delimited)
  and Excel (`.xlsx`/`.xls`) input files with 5 columns
  (`alpha, T1, T2, T3, T4`).
- Uniform-alpha-grid interpolation (`interpolate_alpha`) so all methods
  are compared on the same conversion grid.
- Five isoconversional kinetic methods, implemented with NumPy/pandas
  only (no SciPy):
  - Friedman (differential)
  - Flynn-Wall-Ozawa (FWO)
  - Kissinger-Akahira-Sunose (KAS)
  - Starink
  - Vyazovkin (advanced/iterative, with a from-scratch golden-section
    minimiser and trapezoidal temperature integral)
- Publication-ready Matplotlib plot of Eₐ(α) with per-method legends
  showing the mean activation energy.
- Desktop GUI (customtkinter) with:
  - Data Preview, Kinetic Plot, and Results Table tabs.
  - Method selection checkboxes, progress bar, and status messages.
  - Background-threaded analysis so the UI never freezes.
- One-click export to a timestamped folder containing:
  - `Ea_vs_alpha.png` (300 dpi), `.svg`, and `.pdf`.
  - `Ea_data.txt` (tab-delimited, Origin-compatible).
  - `Ea_results.xlsx` (two sheets: full table + averages).
- Full pytest suite (37 tests), including a synthetic-data validation
  test that verifies every method recovers a known, ground-truth
  activation energy to within 5-10%.
- Packaging via `pyproject.toml` (installable, with an
  `isokinetics-gui` console-script entry point) and a pinned
  `requirements.txt` for fully reproducible environments.
- GitHub Actions CI workflow running the test suite under Xvfb.

### Notes
- The Vyazovkin objective function implemented here follows the
  standard formulation (S. Vyazovkin, *J. Comput. Chem.* 18 (1997) 393),
  which weights each pairwise integral ratio by the corresponding
  heating-rate ratio (βⱼ/βᵢ). This weighting is essential: without it,
  the objective function has no interior minimum on real data and is
  monotonically minimised as Eₐ → 0, which is not physically meaningful.
  This was verified numerically during development (see
  `tests/test_kinetics.py`).
