"""
Smoke tests for isokinetics.gui.

These tests actually instantiate the customtkinter application, so they
require a display server. On headless CI runners, run under Xvfb, e.g.:

    xvfb-run -a pytest tests/test_gui_smoke.py

Tests are automatically skipped if no display / tkinter backend is
available (for example, when running on a machine with no X server and
no virtual display configured).
"""

from __future__ import annotations

import os

import pytest

pytest.importorskip("tkinter")
pytest.importorskip("customtkinter")


def _display_available() -> bool:
    try:
        import tkinter as tk

        root = tk.Tk()
        root.destroy()
        return True
    except Exception:
        return False


pytestmark = pytest.mark.skipif(
    not _display_available(),
    reason="No display available for GUI smoke tests (run under Xvfb).",
)

SAMPLE_FILE = os.path.join(
    os.path.dirname(__file__), "..", "sample_data", "matric_121459.txt"
)


@pytest.fixture
def app():
    from isokinetics.gui import KineticsApp

    application = KineticsApp()
    yield application
    application.destroy()


def test_app_constructs_with_expected_widgets(app):
    assert app.title() != ""
    assert len(app.beta_entries) == 4
    assert set(app.method_vars.keys()) == {
        "Friedman",
        "FWO",
        "KAS",
        "Starink",
        "Vyazovkin",
        "KTH",
    }


def test_read_betas_returns_defaults(app):
    betas = app._read_betas()
    assert betas == [5.0, 10.0, 20.0, 40.0]


def test_read_betas_rejects_non_numeric(app):
    app.beta_entries[0].delete(0, "end")
    app.beta_entries[0].insert(0, "not-a-number")
    with pytest.raises(ValueError):
        app._read_betas()


def test_read_betas_rejects_non_positive(app):
    app.beta_entries[0].delete(0, "end")
    app.beta_entries[0].insert(0, "-5")
    with pytest.raises(ValueError):
        app._read_betas()


def test_load_and_run_end_to_end(app):
    from isokinetics import data_loader, kinetics

    df = data_loader.load_data(SAMPLE_FILE)
    app.working_df = data_loader.interpolate_alpha(df)
    app.raw_df = df
    app._populate_preview(df)

    betas = app._read_betas()
    results = {
        name: kinetics.METHODS[name](app.working_df, betas)
        for name in app.method_vars.keys()
    }
    app._on_analysis_done(
        results, {n: kinetics.average_ea(r) for n, r in results.items()}, {}
    )

    assert app.results
    assert app.export_button.cget("state") == "normal"
    # Results table should contain the average row plus one row per alpha.
    children = app.results_tree.get_children()
    assert len(children) == len(app.working_df) + 1


def test_kth_full_triplet_mode_populates_kth_full_result(app):
    """
    Selecting KTH's "Full triplet" mode should run kth_full() (not the
    plain kth()), store the rich result on the app, and populate both
    the results table's KTH_A/KTH_f(alpha) columns and the KTH Model
    diagnostic plot.
    """
    from isokinetics import data_loader, gui as gui_module, kinetics

    df = data_loader.load_data(SAMPLE_FILE)
    app.working_df = data_loader.interpolate_alpha(df)
    app.raw_df = df
    app._populate_preview(df)

    app.kth_mode_var.set(gui_module.KTH_MODE_FULL_TRIPLET)
    betas = app._read_betas()

    full = kinetics.kth_full(app.working_df, betas)
    results = {"KTH": full["Ea"]}
    averages = {"KTH": kinetics.average_ea(full["Ea"])}

    app._on_analysis_done(results, averages, {}, kth_full_result=full)

    assert app.kth_full_result is not None
    assert app.kth_full_result["model"] == full["model"]

    # The results table should have KTH_A / KTH_f(alpha) columns with
    # real (non-placeholder) values whenever a model was identified.
    children = app.results_tree.get_children()
    assert len(children) == len(app.working_df) + 1
    avg_row_values = app.results_tree.item(children[0], "values")
    assert avg_row_values[0] == "(average)"
    # Last column of the average row should mention the identified model.
    assert "model=" in avg_row_values[-1]


def test_kth_mode_defaults_to_ea_only(app):
    from isokinetics import gui as gui_module

    assert app.kth_mode_var.get() == gui_module.KTH_MODE_EA_ONLY


def test_loading_new_data_resets_kth_full_result(app):
    from isokinetics import data_loader

    app.kth_full_result = {"model": "F1"}  # pretend a previous run happened
    df = data_loader.load_data(SAMPLE_FILE)
    app.raw_df = df
    app.working_df = data_loader.interpolate_alpha(df)
    app._populate_preview(df)
    app.kth_full_result = None  # emulate what _on_load_data does on a fresh load

    assert app.kth_full_result is None
