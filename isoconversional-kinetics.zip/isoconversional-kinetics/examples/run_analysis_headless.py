"""
run_analysis_headless.py
=========================
Example: use the isokinetics library directly (no GUI) to analyse the
bundled sample dataset and export results to ./output/.

Run from the repository root:

    python examples/run_analysis_headless.py
"""

from __future__ import annotations

import os
import sys

# Allow running this example directly from a source checkout without
# installing the package first.
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from isokinetics import data_loader, exporter, kinetics, plotter  # noqa: E402


def main() -> None:
    repo_root = os.path.join(os.path.dirname(__file__), "..")
    sample_file = os.path.join(repo_root, "sample_data", "matric_121459.txt")
    output_dir = os.path.join(repo_root, "output")
    os.makedirs(output_dir, exist_ok=True)

    print(f"Loading data from: {sample_file}")
    df = data_loader.load_data(sample_file)
    df = data_loader.interpolate_alpha(df)

    betas = [5.0, 10.0, 20.0, 40.0]  # K/min

    print("Running all isoconversional methods...")
    results = {name: func(df, betas) for name, func in kinetics.METHODS.items()}
    averages = {name: kinetics.average_ea(res) for name, res in results.items()}

    print("\nAverage activation energies (kJ/mol):")
    for name, avg in averages.items():
        print(f"  {name:10s}: {avg:8.2f}")

    fig = plotter.build_figure()
    plotter.update_plot(fig, results, averages)

    out_folder = exporter.export_all(output_dir, results, fig)
    print(f"\nResults exported to: {out_folder}")


if __name__ == "__main__":
    main()
