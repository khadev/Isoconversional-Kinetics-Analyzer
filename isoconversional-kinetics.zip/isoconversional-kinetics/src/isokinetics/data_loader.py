"""
data_loader.py
================
Utilities for loading, validating, and pre-processing isoconversional
kinetics data: conversion (alpha) vs. temperature (T), measured at four
different heating rates (beta).

The expected raw data layout (5 columns, no header required) is:

    alpha   T1   T2   T3   T4

where T1..T4 are the temperatures (Kelvin) at which the given alpha was
reached, one column per heating rate.
"""

from __future__ import annotations

import os
from typing import Optional

import numpy as np
import pandas as pd

#: Canonical column names used throughout the rest of the application.
EXPECTED_COLUMNS = ["alpha", "T1", "T2", "T3", "T4"]


def load_data(filepath: str) -> pd.DataFrame:
    """
    Load a data file containing conversion (alpha) and temperature values
    for four heating rates.

    Supports plain text files (space, tab, or comma/semicolon delimited)
    and Excel workbooks (.xlsx/.xls). Only the first five columns are
    used; any extra columns are ignored.

    Parameters
    ----------
    filepath : str
        Path to the data file.

    Returns
    -------
    pandas.DataFrame
        Cleaned DataFrame with columns ``["alpha", "T1", "T2", "T3",
        "T4"]``, sorted by ascending alpha.

    Raises
    ------
    FileNotFoundError
        If the file does not exist.
    ValueError
        If the file cannot be parsed, or does not contain at least five
        usable numeric columns / three usable rows.
    """
    if not os.path.isfile(filepath):
        raise FileNotFoundError(f"File not found: {filepath}")

    ext = os.path.splitext(filepath)[1].lower()

    if ext in (".xlsx", ".xls"):
        raw = pd.read_excel(filepath, header=None)
    else:
        raw = _read_text_table(filepath)

    return validate_data(raw)


def _read_text_table(filepath: str) -> pd.DataFrame:
    """
    Attempt to parse a delimited text file trying several common
    separators used by thermal-analysis software (whitespace, tab,
    comma, semicolon).

    Parameters
    ----------
    filepath : str
        Path to the text file.

    Returns
    -------
    pandas.DataFrame
        Raw (un-validated) parsed table.

    Raises
    ------
    ValueError
        If no separator produces a table with >= 5 columns.
    """
    last_error: Optional[Exception] = None
    for sep in [r"\s+", "\t", ",", ";"]:
        try:
            candidate = pd.read_csv(
                filepath,
                sep=sep,
                engine="python",
                header=None,
                comment="#",
                skip_blank_lines=True,
            )
            if candidate.shape[1] >= 5:
                return candidate
        except Exception as exc:  # noqa: BLE001 - we want to try the next separator
            last_error = exc
            continue

    raise ValueError(
        f"Could not parse '{filepath}' as a delimited text file "
        f"(tried whitespace/tab/comma/semicolon). Last error: {last_error}"
    )


def validate_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Validate and normalise a raw DataFrame loaded from disk.

    Steps performed:
        1. Keep only the first five columns.
        2. Rename them to ``alpha, T1, T2, T3, T4``.
        3. Coerce every value to numeric (non-numeric entries -> NaN).
        4. Drop rows containing any NaN.
        5. Sort by ascending alpha and reset the index.

    Parameters
    ----------
    df : pandas.DataFrame
        Raw DataFrame as loaded from file (may have more than 5 columns).

    Returns
    -------
    pandas.DataFrame
        Cleaned, validated DataFrame.

    Raises
    ------
    ValueError
        If fewer than 5 columns are present, or fewer than 3 valid rows
        remain after cleaning.
    """
    if df.shape[1] < 5:
        raise ValueError(
            f"Expected at least 5 columns (alpha, T1..T4), got {df.shape[1]}."
        )

    clean = df.iloc[:, :5].copy()
    clean.columns = EXPECTED_COLUMNS

    for col in EXPECTED_COLUMNS:
        clean[col] = pd.to_numeric(clean[col], errors="coerce")

    clean = clean.dropna(axis=0, how="any")

    if len(clean) < 3:
        raise ValueError(
            "Not enough valid numeric rows found in the data file "
            "(at least 3 rows with alpha, T1, T2, T3, T4 are required)."
        )

    # Basic physical sanity checks (non-fatal -> raise with a clear message)
    if (clean["alpha"] < 0).any() or (clean["alpha"] > 1).any():
        raise ValueError("Column 'alpha' must contain values between 0 and 1.")
    for col in ["T1", "T2", "T3", "T4"]:
        if (clean[col] <= 0).any():
            raise ValueError(
                f"Column '{col}' must contain strictly positive temperatures (Kelvin)."
            )

    clean = clean.sort_values("alpha").reset_index(drop=True)
    return clean


def interpolate_alpha(
    df: pd.DataFrame,
    alpha_min: float = 0.01,
    alpha_max: float = 0.99,
    step: float = 0.01,
) -> pd.DataFrame:
    """
    Resample the temperature columns onto a uniform alpha grid using
    linear interpolation, so that all isoconversional methods are
    evaluated at exactly the same set of alpha values.

    If interpolation is not possible or not sensible (fewer than 4
    original points, or an empty overlap with the requested range), the
    original DataFrame is returned unchanged.

    Parameters
    ----------
    df : pandas.DataFrame
        Validated data with columns alpha, T1, T2, T3, T4.
    alpha_min : float, optional
        Minimum alpha value of the output grid (default 0.01).
    alpha_max : float, optional
        Maximum alpha value of the output grid (default 0.99).
    step : float, optional
        Spacing of the output alpha grid (default 0.01).

    Returns
    -------
    pandas.DataFrame
        DataFrame resampled on the uniform alpha grid, or the original
        DataFrame if resampling could not be performed safely.
    """
    if len(df) < 4:
        return df.copy()

    a_orig = df["alpha"].to_numpy()

    lo = max(alpha_min, float(a_orig.min()))
    hi = min(alpha_max, float(a_orig.max()))
    if hi <= lo:
        return df.copy()

    n_points = int(round((hi - lo) / step)) + 1
    if n_points < 3:
        return df.copy()

    grid = np.linspace(lo, hi, n_points)

    out = {"alpha": grid}
    for col in ["T1", "T2", "T3", "T4"]:
        out[col] = np.interp(grid, a_orig, df[col].to_numpy())

    return pd.DataFrame(out)
