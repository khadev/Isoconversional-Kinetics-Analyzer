"""
gui.py
======
Desktop GUI for the isoconversional kinetics toolkit, built with
customtkinter.

Layout
------
* Top frame   : file selection + the four heating-rate entry fields.
* Middle area : a CTkTabview with three tabs (Data Preview, Kinetic
  Plot, Results Table).
* Bottom frame: method checkboxes, Run/Export buttons, progress bar and
  status label.

All heavy computation (running the isoconversional methods) happens in
a background thread so the UI never freezes; progress and results are
marshalled back to the main thread with ``after()``.
"""

from __future__ import annotations

import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from typing import Dict, List, Optional

import customtkinter as ctk
import pandas as pd

try:
    import darkdetect
except Exception:  # pragma: no cover - darkdetect is optional at runtime
    darkdetect = None

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

from . import data_loader, exporter, kinetics, plotter
from ._tk_utils import cancel_all_pending_after_callbacks

APP_TITLE = "Isoconversional Kinetics Analyzer"
DEFAULT_BETAS = [5.0, 10.0, 20.0, 40.0]
METHOD_NAMES = ["Friedman", "FWO", "KAS", "Starink", "Vyazovkin", "KTH"]

#: The two KTH computation modes selectable in the GUI.
KTH_MODE_EA_ONLY = "E\u2090 only"
KTH_MODE_FULL_TRIPLET = "Full triplet (A, f(\u03b1), model)"


class KineticsApp(ctk.CTk):
    """Main application window."""

    def __init__(self) -> None:
        super().__init__()

        # --- appearance -----------------------------------------------------
        mode = "System"
        if darkdetect is not None:
            try:
                mode = "Dark" if darkdetect.isDark() else "Light"
            except Exception:  # pragma: no cover
                mode = "System"
        ctk.set_appearance_mode(mode)
        ctk.set_default_color_theme("blue")

        self.title(APP_TITLE)
        self.geometry("1150x760")
        self.minsize(950, 640)

        # --- state ------------------------------------------------------------
        self.raw_df: Optional[pd.DataFrame] = None
        self.working_df: Optional[pd.DataFrame] = None
        self.results: Dict[str, Dict[float, float]] = {}
        self.averages: Dict[str, float] = {}
        self.file_path: Optional[str] = None
        self.is_running = False  # True while an analysis computation is in progress
        self.kth_full_result: Optional[Dict[str, object]] = None  # set only when KTH ran in "Full triplet" mode

        # --- shutdown / lifecycle state -----------------------------------
        # `_alive` is False as soon as the window starts closing. Any
        # background-thread callback marshalled in via `self.after(...)`
        # checks this flag before touching a widget, since a callback may
        # already be queued at the moment the user clicks the close
        # button. `_stop_event` is the signal *to* the background thread
        # that it should stop as soon as convenient; `_analysis_thread`
        # is kept so shutdown can wait briefly for it to notice and exit.
        self._alive = True
        self._stop_event = threading.Event()
        self._analysis_thread: Optional[threading.Thread] = None

        self._build_top_frame()
        self._build_tabview()
        self._build_bottom_frame()

        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ------------------------------------------------------------------ #
    # UI construction
    # ------------------------------------------------------------------ #
    def _build_top_frame(self) -> None:
        top = ctk.CTkFrame(self)
        top.pack(side="top", fill="x", padx=10, pady=(10, 5))

        self.load_button = ctk.CTkButton(
            top, text="Load Data", width=120, command=self._on_load_data
        )
        self.load_button.grid(row=0, column=0, padx=(10, 10), pady=10)

        self.file_label = ctk.CTkLabel(
            top, text="No file loaded.", anchor="w", text_color=("gray20", "gray80")
        )
        self.file_label.grid(row=0, column=1, columnspan=4, sticky="w", padx=5)

        ctk.CTkLabel(top, text="Heating rates \u03b2 (K/min):").grid(
            row=1, column=0, padx=(10, 5), pady=(5, 10), sticky="w"
        )

        self.beta_entries: List[ctk.CTkEntry] = []
        for i, default in enumerate(DEFAULT_BETAS):
            entry = ctk.CTkEntry(top, width=80, placeholder_text=f"\u03b2{i + 1}")
            entry.insert(0, str(default))
            entry.grid(row=1, column=1 + i, padx=5, pady=(5, 10))
            self.beta_entries.append(entry)

        ctk.CTkLabel(top, text="KTH mode:").grid(
            row=2, column=0, padx=(10, 5), pady=(0, 10), sticky="w"
        )
        self.kth_mode_var = ctk.StringVar(value=KTH_MODE_EA_ONLY)
        self.kth_mode_menu = ctk.CTkOptionMenu(
            top,
            values=[KTH_MODE_EA_ONLY, KTH_MODE_FULL_TRIPLET],
            variable=self.kth_mode_var,
            width=240,
        )
        self.kth_mode_menu.grid(
            row=2, column=1, columnspan=3, padx=5, pady=(0, 10), sticky="w"
        )

        for col in range(6):
            top.grid_columnconfigure(col, weight=0)
        top.grid_columnconfigure(4, weight=1)

    def _build_tabview(self) -> None:
        self.tabview = ctk.CTkTabview(self)
        self.tabview.pack(side="top", fill="both", expand=True, padx=10, pady=5)

        self.tab_preview = self.tabview.add("Data Preview")
        self.tab_plot = self.tabview.add("Kinetic Plot")
        self.tab_results = self.tabview.add("Results Table")
        self.tab_kth = self.tabview.add("KTH Model")

        self._build_preview_tab()
        self._build_plot_tab()
        self._build_results_tab()
        self._build_kth_tab()

    def _build_preview_tab(self) -> None:
        container = ctk.CTkFrame(self.tab_preview, fg_color="transparent")
        container.pack(fill="both", expand=True, padx=5, pady=5)

        columns = ["alpha", "T1", "T2", "T3", "T4"]
        self.preview_tree = ttk.Treeview(
            container, columns=columns, show="headings", height=20
        )
        for col in columns:
            self.preview_tree.heading(col, text=col)
            self.preview_tree.column(col, width=120, anchor="center")

        vsb = ttk.Scrollbar(container, orient="vertical", command=self.preview_tree.yview)
        self.preview_tree.configure(yscrollcommand=vsb.set)

        self.preview_tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

    def _build_plot_tab(self) -> None:
        self.figure = plotter.build_figure()
        self.canvas = FigureCanvasTkAgg(self.figure, master=self.tab_plot)
        self.canvas.get_tk_widget().pack(fill="both", expand=True, padx=5, pady=5)
        self.canvas.draw()

    def _build_results_tab(self) -> None:
        container = ctk.CTkFrame(self.tab_results, fg_color="transparent")
        container.pack(fill="both", expand=True, padx=5, pady=5)

        columns = ["alpha"] + METHOD_NAMES + ["KTH_A", "KTH_f(\u03b1)"]
        self.results_tree = ttk.Treeview(
            container, columns=columns, show="headings", height=20
        )
        for col in columns:
            self.results_tree.heading(col, text=col)
            self.results_tree.column(col, width=110, anchor="center")

        vsb = ttk.Scrollbar(container, orient="vertical", command=self.results_tree.yview)
        self.results_tree.configure(yscrollcommand=vsb.set)

        self.results_tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

    def _build_kth_tab(self) -> None:
        self.kth_figure = plotter.build_kth_model_figure()
        self.kth_canvas = FigureCanvasTkAgg(self.kth_figure, master=self.tab_kth)
        self.kth_canvas.get_tk_widget().pack(fill="both", expand=True, padx=5, pady=5)
        self.kth_canvas.draw()

    def _build_bottom_frame(self) -> None:
        bottom = ctk.CTkFrame(self)
        bottom.pack(side="bottom", fill="x", padx=10, pady=(5, 10))

        method_frame = ctk.CTkFrame(bottom, fg_color="transparent")
        method_frame.pack(side="top", fill="x", padx=5, pady=(5, 0))

        ctk.CTkLabel(method_frame, text="Methods:").pack(side="left", padx=(5, 10))

        self.method_vars: Dict[str, ctk.BooleanVar] = {}
        for name in METHOD_NAMES:
            var = ctk.BooleanVar(value=True)
            cb = ctk.CTkCheckBox(method_frame, text=name, variable=var)
            cb.pack(side="left", padx=8)
            self.method_vars[name] = var

        action_frame = ctk.CTkFrame(bottom, fg_color="transparent")
        action_frame.pack(side="top", fill="x", padx=5, pady=8)

        self.run_button = ctk.CTkButton(
            action_frame, text="Run Analysis", width=140, command=self._on_run_analysis
        )
        self.run_button.pack(side="left", padx=(5, 10))

        self.export_button = ctk.CTkButton(
            action_frame,
            text="Export",
            width=120,
            command=self._on_export,
            state="disabled",
        )
        self.export_button.pack(side="left", padx=5)

        self.progress_bar = ctk.CTkProgressBar(action_frame)
        self.progress_bar.pack(side="left", fill="x", expand=True, padx=15)
        self.progress_bar.set(0.0)

        self.status_label = ctk.CTkLabel(bottom, text="Ready.", anchor="w")
        self.status_label.pack(side="top", fill="x", padx=10, pady=(0, 5))

    # ------------------------------------------------------------------ #
    # Event handlers
    # ------------------------------------------------------------------ #
    def _on_load_data(self) -> None:
        path = filedialog.askopenfilename(
            title="Select kinetics data file",
            filetypes=[
                ("Data files", "*.txt *.csv *.dat *.xlsx *.xls"),
                ("All files", "*.*"),
            ],
        )
        if not path:
            return

        try:
            df = data_loader.load_data(path)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Load error", str(exc))
            return

        self.raw_df = df
        self.working_df = data_loader.interpolate_alpha(df)
        self.file_path = path
        self.file_label.configure(text=f"Loaded: {path}  ({len(df)} rows)")
        self._populate_preview(df)
        self._set_status(f"Loaded {len(df)} rows from {path}.")

        # Reset previous results whenever new data is loaded.
        self.results = {}
        self.averages = {}
        self.kth_full_result = None
        self.export_button.configure(state="disabled")
        plotter.update_plot(self.figure, {})
        self.canvas.draw()
        plotter.update_kth_model_plot(self.kth_figure, None)
        self.kth_canvas.draw()
        self._clear_results_table()

    def _on_run_analysis(self) -> None:
        if self.is_running:
            return

        if self.working_df is None:
            messagebox.showwarning("No data", "Please load a data file first.")
            return

        selected = [name for name, var in self.method_vars.items() if var.get()]
        if not selected:
            messagebox.showwarning(
                "No method selected", "Please select at least one kinetic method."
            )
            return

        try:
            betas = self._read_betas()
        except ValueError as exc:
            messagebox.showerror("Invalid heating rates", str(exc))
            return

        self._set_running_state(True)
        self._set_status("Running analysis...")
        self.progress_bar.set(0.0)

        kth_mode = self.kth_mode_var.get()

        self._stop_event.clear()
        thread = threading.Thread(
            target=self._run_analysis_worker,
            args=(selected, betas, kth_mode),
            daemon=True,
        )
        self._analysis_thread = thread
        thread.start()

    def _run_analysis_worker(
        self, selected: List[str], betas: List[float], kth_mode: str
    ) -> None:
        """Runs in a background thread; must not touch Tk widgets directly."""
        results: Dict[str, Dict[float, float]] = {}
        errors: Dict[str, str] = {}
        kth_full_result: Optional[Dict[str, object]] = None
        n = len(selected)

        for idx, name in enumerate(selected):
            if self._stop_event.is_set():
                return  # window is closing -- abandon without touching widgets

            try:
                if name == "KTH" and kth_mode == KTH_MODE_FULL_TRIPLET:
                    full = kinetics.kth_full(self.working_df, betas)
                    kth_full_result = full
                    results[name] = full["Ea"]
                else:
                    func = kinetics.METHODS[name]
                    results[name] = func(self.working_df, betas)
            except Exception as exc:  # noqa: BLE001
                errors[name] = str(exc)
                results[name] = {}

            if self._stop_event.is_set():
                return

            progress = (idx + 1) / n
            self.after(0, self._update_progress, progress, name)

        if self._stop_event.is_set():
            return

        averages = {name: kinetics.average_ea(res) for name, res in results.items()}

        self.after(0, self._on_analysis_done, results, averages, errors, kth_full_result)

    def _update_progress(self, fraction: float, method_name: str) -> None:
        if not self._alive:
            return
        self.progress_bar.set(fraction)
        self._set_status(f"Computed {method_name}... ({fraction * 100:.0f}%)")

    def _on_analysis_done(
        self,
        results: Dict[str, Dict[float, float]],
        averages: Dict[str, float],
        errors: Dict[str, str],
        kth_full_result: Optional[Dict[str, object]] = None,
    ) -> None:
        if not self._alive:
            return

        self.results = results
        self.averages = averages
        self.kth_full_result = kth_full_result

        plotter.update_plot(self.figure, results, averages)
        self.canvas.draw()

        plotter.update_kth_model_plot(self.kth_figure, kth_full_result)
        self.kth_canvas.draw()

        self._populate_results_table(results)

        self._set_running_state(False)
        self.export_button.configure(state="normal" if results else "disabled")

        if errors:
            detail = "\n".join(f"- {k}: {v}" for k, v in errors.items())
            messagebox.showwarning(
                "Some methods failed",
                f"The following method(s) could not be computed:\n{detail}",
            )
            self._set_status("Analysis finished with warnings.")
        else:
            self._set_status("Analysis complete.")

    def _on_export(self) -> None:
        if not self.results:
            messagebox.showwarning("Nothing to export", "Run an analysis first.")
            return

        folder = filedialog.askdirectory(title="Select destination folder")
        if not folder:
            return

        try:
            out_path = exporter.export_all(
                folder,
                self.results,
                self.figure,
                kth_full_result=self.kth_full_result,
                kth_figure=self.kth_figure,
            )
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Export error", str(exc))
            return

        messagebox.showinfo("Export complete", f"Results saved to:\n{out_path}")
        self._set_status(f"Exported to {out_path}")

    def _on_close(self) -> None:
        """Handle the window's close button (WM_DELETE_WINDOW)."""
        self._shutdown()

    def destroy(self) -> None:
        """
        Override so that *any* code path that closes this window (the
        close button via :meth:`_on_close`, a test calling
        ``app.destroy()`` directly, etc.) goes through the same clean
        shutdown sequence exactly once.

        Calling this more than once is safe and simply does nothing on
        the second call: the underlying ``tkinter.Tk.destroy()`` is
        *not* itself idempotent (it raises ``TclError: can't invoke
        "destroy" command: application has been destroyed`` if called
        again after the Tcl interpreter is actually gone), so we must
        not call it twice ourselves.
        """
        if self._alive:
            self._shutdown()

    def _shutdown(self) -> None:
        """
        Clean shutdown sequence, run exactly once:

        1. Mark the app as no longer alive. Any background-thread
           callback already queued via ``self.after(...)`` (e.g.
           :meth:`_update_progress`) checks this flag first and becomes
           a no-op instead of touching widgets that are about to be
           destroyed.
        2. Signal the analysis thread (if one is running) to stop via
           ``_stop_event``, and give it a brief moment to notice and
           return on its own. It's a daemon thread, so this is a
           courtesy for a clean-looking shutdown, not a requirement for
           the process to exit.
        3. Cancel every pending Tk ``after``/``after_idle`` callback --
           including ones customtkinter schedules internally for itself
           (its DPI-scaling and appearance-mode polling loops) -- so
           none of them can fire once the widgets they reference are
           gone. Without this, closing the window can print stray
           ``invalid command name ... ("after" script)`` errors to the
           console. See :mod:`isokinetics._tk_utils` for the full
           explanation.
        4. Destroy the window.
        """
        self._alive = False
        self._stop_event.set()

        if self._analysis_thread is not None and self._analysis_thread.is_alive():
            self._analysis_thread.join(timeout=0.5)

        cancel_all_pending_after_callbacks(self)
        super().destroy()

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #
    def _read_betas(self) -> List[float]:
        betas = []
        for i, entry in enumerate(self.beta_entries):
            text = entry.get().strip()
            try:
                value = float(text)
            except ValueError:
                raise ValueError(f"Heating rate #{i + 1} ('{text}') is not a valid number.")
            if value <= 0:
                raise ValueError(f"Heating rate #{i + 1} must be a positive number.")
            betas.append(value)
        return betas

    def _populate_preview(self, df: pd.DataFrame) -> None:
        self.preview_tree.delete(*self.preview_tree.get_children())
        for _, row in df.iterrows():
            values = [f"{row['alpha']:.4f}"] + [f"{row[c]:.3f}" for c in ["T1", "T2", "T3", "T4"]]
            self.preview_tree.insert("", "end", values=values)

    def _clear_results_table(self) -> None:
        self.results_tree.delete(*self.results_tree.get_children())

    def _populate_results_table(self, results: Dict[str, Dict[float, float]]) -> None:
        self._clear_results_table()

        all_alphas = sorted(
            {a for method_results in results.values() for a in method_results.keys()}
        )

        kth_A = self.kth_full_result["A"] if self.kth_full_result else {}
        kth_f = self.kth_full_result["f_alpha"] if self.kth_full_result else {}

        for a in all_alphas:
            row = [f"{a:.4f}"]
            for name in METHOD_NAMES:
                if name in results:
                    ea = results[name].get(a, float("nan"))
                    row.append(f"{ea:.2f}" if ea == ea else "N/A")
                else:
                    row.append("-")

            a_val = kth_A.get(a, float("nan"))
            f_val = kth_f.get(a, float("nan"))
            row.append(f"{a_val:.3e}" if a_val == a_val else "-")
            row.append(f"{f_val:.4f}" if f_val == f_val else "-")

            self.results_tree.insert("", "end", values=row)

        # Add an "average" summary row at the top for convenience.
        avg_row = ["(average)"]
        for name in METHOD_NAMES:
            if name in results:
                avg = kinetics.average_ea(results[name])
                avg_row.append(f"{avg:.2f}" if avg == avg else "N/A")
            else:
                avg_row.append("-")

        if self.kth_full_result:
            finite_A = [v for v in kth_A.values() if v == v]
            avg_row.append(f"{sum(finite_A) / len(finite_A):.3e}" if finite_A else "-")
            avg_row.append(f"model={self.kth_full_result.get('model', '-')}")
        else:
            avg_row.append("-")
            avg_row.append("-")

        self.results_tree.insert("", 0, values=avg_row)

    def _set_running_state(self, running: bool) -> None:
        self.is_running = running
        state = "disabled" if running else "normal"
        self.run_button.configure(state=state)
        self.load_button.configure(state=state)
        for entry in self.beta_entries:
            entry.configure(state=state)

    def _set_status(self, message: str) -> None:
        self.status_label.configure(text=message)


def run() -> None:
    """Instantiate and start the GUI main loop."""
    app = KineticsApp()
    app.mainloop()
