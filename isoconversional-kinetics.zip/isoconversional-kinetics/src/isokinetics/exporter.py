"""
exporter.py
===========
Functions to persist analysis results (graphs and numeric data) to a
timestamped output folder, in formats convenient for further use:

* Ea_vs_alpha.png / .svg / .pdf  -- the plot, in three common formats.
* Ea_data.txt                    -- tab-delimited text, directly
                                     importable into Origin, Excel, etc.
* Ea_results.xlsx                -- optional multi-sheet Excel workbook.
"""

from __future__ import annotations

import datetime as _dt
import os
from typing import Dict, Optional

from matplotlib.figure import Figure

from .kinetics import average_ea


def make_output_folder(base_dir: str) -> str:
    """
    Create (and return the path to) a new timestamped subfolder inside
    ``base_dir``, named ``Kinetics_Results_YYYYMMDD_HHMMSS``.

    Parameters
    ----------
    base_dir : str
        Directory chosen by the user (must already exist).

    Returns
    -------
    str
        Full path to the newly created subfolder.
    """
    if not os.path.isdir(base_dir):
        raise FileNotFoundError(f"Base directory does not exist: {base_dir}")

    timestamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    folder_name = f"Kinetics_Results_{timestamp}"
    out_path = os.path.join(base_dir, folder_name)
    os.makedirs(out_path, exist_ok=False)
    return out_path


def save_graph(fig: Figure, out_folder: str, basename: str = "Ea_vs_alpha") -> Dict[str, str]:
    """
    Save the given matplotlib figure to PNG (300 dpi), SVG, and PDF.

    Parameters
    ----------
    fig : matplotlib.figure.Figure
        The figure to export (as currently drawn).
    out_folder : str
        Destination folder (must exist).
    basename : str, optional
        File name (without extension) used for all three formats.

    Returns
    -------
    dict
        Mapping of format -> full file path written.
    """
    paths = {}
    for ext, kwargs in (
        ("png", {"dpi": 300}),
        ("svg", {}),
        ("pdf", {}),
    ):
        path = os.path.join(out_folder, f"{basename}.{ext}")
        fig.savefig(path, bbox_inches="tight", **kwargs)
        paths[ext] = path
    return paths


def save_data_txt(
    results: Dict[str, Dict[float, float]],
    out_folder: str,
    filename: str = "Ea_data.txt",
    averages: Optional[Dict[str, float]] = None,
    kth_full_result: Optional[Dict[str, object]] = None,
) -> str:
    """
    Write a tab-delimited text file with the Ea(alpha) results for every
    method, directly importable into Origin (or any spreadsheet/plotting
    tool that reads tab-delimited text).

    File layout::

        alpha    Friedman   FWO   KAS   Starink   Vyazovkin
        (avg)    98.3       83.8  78.1  78.4      78.6
        0.01     ...        ...   ...   ...       ...
        0.02     ...        ...   ...   ...       ...
        ...

    If ``kth_full_result`` is provided (i.e. KTH was run in "Full
    triplet" mode), two extra columns -- ``KTH_A`` (pre-exponential
    factor, s^-1) and ``KTH_f_alpha`` (identified reaction model's
    value) -- are appended, along with a comment line naming the
    identified model.

    Parameters
    ----------
    results : dict
        Mapping ``method_name -> {alpha: Ea}``.
    out_folder : str
        Destination folder (must exist).
    filename : str, optional
        Output file name (default ``Ea_data.txt``).
    averages : dict, optional
        Mapping ``method_name -> average Ea``. Computed automatically if
        omitted.
    kth_full_result : dict, optional
        The dict returned by :func:`isokinetics.kinetics.kth_full`, if
        KTH was run in "Full triplet" mode. Adds ``KTH_A`` and
        ``KTH_f_alpha`` columns when present.

    Returns
    -------
    str
        Full path to the written file.
    """
    method_names = list(results.keys())
    if averages is None:
        averages = {name: average_ea(results[name]) for name in method_names}

    # Union of every alpha value seen across all methods, sorted ascending.
    all_alphas = sorted(
        {a for method_results in results.values() for a in method_results.keys()}
    )

    kth_A = kth_full_result["A"] if kth_full_result else {}
    kth_f = kth_full_result["f_alpha"] if kth_full_result else {}
    extra_cols = ["KTH_A", "KTH_f_alpha"] if kth_full_result else []

    path = os.path.join(out_folder, filename)
    with open(path, "w", encoding="utf-8") as fh:
        if kth_full_result is not None:
            fh.write(f"# KTH identified reaction model: {kth_full_result.get('model', 'unknown')}\n")

        header = ["alpha"] + method_names + extra_cols
        fh.write("\t".join(header) + "\n")

        avg_row = ["(average)"] + [
            f"{averages.get(name, float('nan')):.4f}" for name in method_names
        ]
        if kth_full_result is not None:
            finite_A = [v for v in kth_A.values() if v == v]
            avg_A = f"{(sum(finite_A) / len(finite_A)):.6e}" if finite_A else "NaN"
            avg_row += [avg_A, "-"]
        fh.write("\t".join(avg_row) + "\n")

        for a in all_alphas:
            row = [f"{a:.4f}"]
            for name in method_names:
                ea = results[name].get(a, float("nan"))
                row.append(f"{ea:.4f}" if ea == ea else "NaN")
            if kth_full_result is not None:
                a_val = kth_A.get(a, float("nan"))
                f_val = kth_f.get(a, float("nan"))
                row.append(f"{a_val:.6e}" if a_val == a_val else "NaN")
                row.append(f"{f_val:.6f}" if f_val == f_val else "NaN")
            fh.write("\t".join(row) + "\n")

    return path


def save_data_xlsx(
    results: Dict[str, Dict[float, float]],
    out_folder: str,
    filename: str = "Ea_results.xlsx",
    averages: Optional[Dict[str, float]] = None,
    kth_full_result: Optional[Dict[str, object]] = None,
) -> str:
    """
    Write an Excel workbook with two sheets: "Ea_vs_alpha" (full table)
    and "Averages" (one row per method). If ``kth_full_result`` is
    provided, the "Ea_vs_alpha" sheet also gets ``KTH_A`` and
    ``KTH_f_alpha`` columns, and a third sheet, "KTH_Model", is added
    with the identified model, its match scores against every candidate,
    and the y(alpha)/z(alpha) diagnostic curves (experimental and
    theoretical).

    Parameters
    ----------
    results : dict
        Mapping ``method_name -> {alpha: Ea}``.
    out_folder : str
        Destination folder (must exist).
    filename : str, optional
        Output file name (default ``Ea_results.xlsx``).
    averages : dict, optional
        Mapping ``method_name -> average Ea``. Computed automatically if
        omitted.
    kth_full_result : dict, optional
        The dict returned by :func:`isokinetics.kinetics.kth_full`, if
        KTH was run in "Full triplet" mode.

    Returns
    -------
    str
        Full path to the written file.
    """
    import pandas as pd  # local import keeps module import light for GUI startup

    method_names = list(results.keys())
    if averages is None:
        averages = {name: average_ea(results[name]) for name in method_names}

    all_alphas = sorted(
        {a for method_results in results.values() for a in method_results.keys()}
    )

    table = {"alpha": all_alphas}
    for name in method_names:
        table[name] = [results[name].get(a, float("nan")) for a in all_alphas]

    if kth_full_result is not None:
        kth_A = kth_full_result["A"]
        kth_f = kth_full_result["f_alpha"]
        table["KTH_A"] = [kth_A.get(a, float("nan")) for a in all_alphas]
        table["KTH_f_alpha"] = [kth_f.get(a, float("nan")) for a in all_alphas]

    df_full = pd.DataFrame(table)

    df_avg = pd.DataFrame(
        {"method": method_names, "average_Ea_kJ_per_mol": [averages[n] for n in method_names]}
    )

    path = os.path.join(out_folder, filename)
    with pd.ExcelWriter(path, engine="xlsxwriter") as writer:
        df_full.to_excel(writer, sheet_name="Ea_vs_alpha", index=False)
        df_avg.to_excel(writer, sheet_name="Averages", index=False)

        if kth_full_result is not None:
            model_scores = kth_full_result.get("model_scores", {}) or {}
            df_model_summary = pd.DataFrame(
                {
                    "identified_model": [kth_full_result.get("model", "unknown")],
                }
            )
            df_scores = pd.DataFrame(
                sorted(model_scores.items(), key=lambda kv: kv[1]),
                columns=["candidate_model", "match_score_lower_is_better"],
            )
            df_curves = pd.DataFrame(
                {
                    "alpha": all_alphas,
                    "y_alpha_experimental": [
                        kth_full_result.get("y_alpha", {}).get(a, float("nan"))
                        for a in all_alphas
                    ],
                    "z_alpha_experimental": [
                        kth_full_result.get("z_alpha", {}).get(a, float("nan"))
                        for a in all_alphas
                    ],
                    "y_alpha_theoretical": [
                        kth_full_result.get("y_theory", {}).get(a, float("nan"))
                        for a in all_alphas
                    ],
                    "z_alpha_theoretical": [
                        kth_full_result.get("z_theory", {}).get(a, float("nan"))
                        for a in all_alphas
                    ],
                }
            )
            df_model_summary.to_excel(
                writer, sheet_name="KTH_Model", index=False, startrow=0
            )
            df_scores.to_excel(writer, sheet_name="KTH_Model", index=False, startrow=3)
            df_curves.to_excel(
                writer,
                sheet_name="KTH_Model",
                index=False,
                startrow=3 + len(df_scores) + 3,
            )

    return path


def export_all(
    base_dir: str,
    results: Dict[str, Dict[float, float]],
    fig: Figure,
    include_excel: bool = True,
    kth_full_result: Optional[Dict[str, object]] = None,
    kth_figure: Optional[Figure] = None,
) -> str:
    """
    Convenience wrapper that creates the timestamped output folder and
    writes graphs, the tab-delimited text file, and (optionally) the
    Excel workbook, in a single call.

    Parameters
    ----------
    base_dir : str
        Directory chosen by the user via the folder-selection dialog.
    results : dict
        Mapping ``method_name -> {alpha: Ea}`` for every method that was
        run.
    fig : matplotlib.figure.Figure
        The currently displayed Ea(alpha) plot.
    include_excel : bool, optional
        Whether to also write the ``.xlsx`` workbook (default True).
    kth_full_result : dict, optional
        The dict returned by :func:`isokinetics.kinetics.kth_full`, if
        KTH was run in "Full triplet" mode. When provided, adds
        ``KTH_A``/``KTH_f_alpha`` columns to the text/Excel exports and
        (if ``kth_figure`` is also given) saves the KTH model diagnostic
        plot alongside the main graph.
    kth_figure : matplotlib.figure.Figure, optional
        The currently displayed KTH model diagnostic plot (y(alpha)/
        z(alpha) vs. the identified model), saved as
        ``KTH_model_plot.png/.svg/.pdf`` when both this and
        ``kth_full_result`` are provided.

    Returns
    -------
    str
        Full path to the created output folder.
    """
    out_folder = make_output_folder(base_dir)
    averages = {name: average_ea(res) for name, res in results.items()}

    save_graph(fig, out_folder)
    if kth_full_result is not None and kth_figure is not None:
        save_graph(kth_figure, out_folder, basename="KTH_model_plot")

    save_data_txt(results, out_folder, averages=averages, kth_full_result=kth_full_result)
    if include_excel:
        save_data_xlsx(
            results, out_folder, averages=averages, kth_full_result=kth_full_result
        )

    return out_folder
