"""
plotter.py
==========
Matplotlib helpers for rendering the Ea(alpha) isoconversional plot.

The plot is designed to be publication-ready: clean grid, Unicode
Greek-letter axis labels, and one legend entry per method carrying its
mean activation energy.
"""

from __future__ import annotations

from typing import Dict, Optional

import matplotlib

matplotlib.use("Agg")  # safe default; the GUI switches to TkAgg explicitly.
import matplotlib.pyplot as plt  # noqa: E402  (import after backend selection)
from matplotlib.figure import Figure  # noqa: E402

#: Consistent colour per method so repeated redraws look stable.
METHOD_COLORS = {
    "Friedman": "#1f77b4",
    "FWO": "#ff7f0e",
    "KAS": "#2ca02c",
    "Starink": "#d62728",
    "Vyazovkin": "#9467bd",
    "KTH": "#e377c2",
}

METHOD_MARKERS = {
    "Friedman": "o",
    "FWO": "s",
    "KAS": "^",
    "Starink": "D",
    "Vyazovkin": "v",
    "KTH": "x",
}


def _apply_clean_style() -> None:
    """Apply a clean, publication-style matplotlib configuration."""
    plt.rcParams.update(
        {
            "font.size": 11,
            "axes.linewidth": 1.0,
            "axes.edgecolor": "#333333",
            "grid.color": "#cccccc",
            "grid.linewidth": 0.6,
            "figure.facecolor": "white",
            "axes.facecolor": "white",
        }
    )


def build_figure() -> Figure:
    """
    Create a fresh, empty matplotlib :class:`~matplotlib.figure.Figure`
    pre-configured with the axis labels, title, and grid used throughout
    the application.

    Returns
    -------
    matplotlib.figure.Figure
        A figure with a single axes, ready to be populated by
        :func:`update_plot`.
    """
    _apply_clean_style()
    fig = Figure(figsize=(7.5, 5.0), dpi=100)
    ax = fig.add_subplot(111)
    _configure_axes(ax)
    fig.tight_layout()
    return fig


def _configure_axes(ax) -> None:
    """Apply consistent labels/title/grid to an Axes instance."""
    ax.set_xlabel("\u03b1 (conversion)")
    ax.set_ylabel("E\u2090 (kJ mol\u207b\u00b9)")
    ax.set_title("Isoconversional Activation Energy")
    ax.grid(True, linestyle="--", alpha=0.6)
    ax.set_xlim(0.0, 1.0)


def update_plot(
    fig: Figure,
    results: Dict[str, Dict[float, float]],
    averages: Optional[Dict[str, float]] = None,
) -> Figure:
    """
    Clear and redraw the given figure with one Ea(alpha) curve per
    method.

    Parameters
    ----------
    fig : matplotlib.figure.Figure
        Figure previously created with :func:`build_figure` (or any
        figure with at least one axes -- it will be cleared).
    results : dict
        Mapping ``method_name -> {alpha: Ea}`` for every method the user
        selected to run.
    averages : dict, optional
        Mapping ``method_name -> average Ea``. If omitted, averages are
        computed on the fly (ignoring NaNs).

    Returns
    -------
    matplotlib.figure.Figure
        The same figure object, redrawn in place (convenient for reuse
        with FigureCanvasTkAgg.draw()).
    """
    fig.clear()
    ax = fig.add_subplot(111)
    _configure_axes(ax)

    if averages is None:
        averages = {}

    any_plotted = False
    for method_name, alpha_to_ea in results.items():
        if not alpha_to_ea:
            continue
        alphas = sorted(alpha_to_ea.keys())
        eas = [alpha_to_ea[a] for a in alphas]

        # Filter out NaNs for plotting, but keep the line contiguous.
        clean_alphas = [a for a, e in zip(alphas, eas) if e == e]  # e == e -> not NaN
        clean_eas = [e for e in eas if e == e]
        if not clean_alphas:
            continue

        avg = averages.get(method_name)
        if avg is None or avg != avg:
            finite = [e for e in clean_eas]
            avg = sum(finite) / len(finite) if finite else float("nan")

        label = f"{method_name} (E\u2090 = {avg:.1f} kJ/mol)"
        color = METHOD_COLORS.get(method_name, None)
        marker = METHOD_MARKERS.get(method_name, "o")

        ax.plot(
            clean_alphas,
            clean_eas,
            marker=marker,
            markersize=3.5,
            linewidth=1.4,
            label=label,
            color=color,
        )
        any_plotted = True

    if any_plotted:
        ax.legend(loc="best", fontsize=9, framealpha=0.9)
    else:
        ax.text(
            0.5,
            0.5,
            "No results to display yet.\nLoad data and click 'Run Analysis'.",
            ha="center",
            va="center",
            transform=ax.transAxes,
            fontsize=11,
            color="#666666",
        )

    fig.tight_layout()
    return fig


def build_kth_model_figure() -> Figure:
    """
    Create a fresh, empty two-panel figure for the KTH model
    identification diagnostic plot: Malek's y(alpha) on the left, z(alpha)
    on the right, each ready to show the experimental curve overlaid
    with the identified theoretical model's curve.

    Returns
    -------
    matplotlib.figure.Figure
        A figure with two axes, ready to be populated by
        :func:`update_kth_model_plot`.
    """
    _apply_clean_style()
    fig = Figure(figsize=(9.0, 4.2), dpi=100)
    ax_y = fig.add_subplot(121)
    ax_z = fig.add_subplot(122)
    _configure_kth_axes(ax_y, ax_z)
    fig.tight_layout()
    return fig


def _configure_kth_axes(ax_y, ax_z) -> None:
    """Apply consistent labels/titles/grids to the two KTH diagnostic axes."""
    ax_y.set_xlabel("\u03b1 (conversion)")
    ax_y.set_ylabel("y(\u03b1)  (normalised)")
    ax_y.set_title("Malek y(\u03b1)")
    ax_y.grid(True, linestyle="--", alpha=0.6)
    ax_y.set_xlim(0.0, 1.0)
    ax_y.set_ylim(-0.05, 1.05)

    ax_z.set_xlabel("\u03b1 (conversion)")
    ax_z.set_ylabel("z(\u03b1)  (normalised)")
    ax_z.set_title("Malek z(\u03b1)")
    ax_z.grid(True, linestyle="--", alpha=0.6)
    ax_z.set_xlim(0.0, 1.0)
    ax_z.set_ylim(-0.05, 1.05)


def update_kth_model_plot(fig: Figure, kth_full_result: Optional[Dict[str, object]]) -> Figure:
    """
    Clear and redraw the KTH model-identification diagnostic figure.

    Plots the experimental Malek y(alpha)/z(alpha) curves (computed by
    :func:`isokinetics.kinetics.kth_full`) against the identified
    theoretical model's own curves, so the quality of the match is
    visible at a glance. If no model could be confidently identified,
    only the experimental curves are shown with a note to that effect.

    Parameters
    ----------
    fig : matplotlib.figure.Figure
        Figure previously created with :func:`build_kth_model_figure`
        (or any figure with two axes -- it will be cleared).
    kth_full_result : dict or None
        The dict returned by :func:`isokinetics.kinetics.kth_full`, or
        ``None`` if KTH's full-triplet mode has not been run yet (in
        which case a placeholder message is shown instead).

    Returns
    -------
    matplotlib.figure.Figure
        The same figure object, redrawn in place.
    """
    fig.clear()
    ax_y = fig.add_subplot(121)
    ax_z = fig.add_subplot(122)
    _configure_kth_axes(ax_y, ax_z)

    if not kth_full_result:
        for ax in (ax_y, ax_z):
            ax.text(
                0.5,
                0.5,
                "Run KTH in\n'Full triplet' mode\nto see this plot.",
                ha="center",
                va="center",
                transform=ax.transAxes,
                fontsize=10,
                color="#666666",
            )
        fig.tight_layout()
        return fig

    model_name = kth_full_result.get("model", "unknown")

    def _sorted_xy(mapping):
        alphas = sorted(mapping.keys())
        values = [mapping[a] for a in alphas]
        clean_a = [a for a, v in zip(alphas, values) if v == v]
        clean_v = [v for v in values if v == v]
        return clean_a, clean_v

    y_a, y_v = _sorted_xy(kth_full_result.get("y_alpha", {}))
    z_a, z_v = _sorted_xy(kth_full_result.get("z_alpha", {}))

    ax_y.plot(y_a, y_v, color="#1f77b4", linewidth=1.6, label="Experimental")
    ax_z.plot(z_a, z_v, color="#1f77b4", linewidth=1.6, label="Experimental")

    if model_name != "unknown":
        yt_a, yt_v = _sorted_xy(kth_full_result.get("y_theory", {}))
        zt_a, zt_v = _sorted_xy(kth_full_result.get("z_theory", {}))
        ax_y.plot(
            yt_a, yt_v, color="#d62728", linewidth=1.4, linestyle="--",
            label=f"Theoretical ({model_name})",
        )
        ax_z.plot(
            zt_a, zt_v, color="#d62728", linewidth=1.4, linestyle="--",
            label=f"Theoretical ({model_name})",
        )
        fig.suptitle(f"KTH Model Identification: {model_name}", fontsize=12)
    else:
        fig.suptitle("KTH Model Identification: unknown (ambiguous match)", fontsize=12)

    ax_y.legend(loc="best", fontsize=8, framealpha=0.9)
    ax_z.legend(loc="best", fontsize=8, framealpha=0.9)

    fig.tight_layout(rect=(0, 0, 1, 0.94))
    return fig
