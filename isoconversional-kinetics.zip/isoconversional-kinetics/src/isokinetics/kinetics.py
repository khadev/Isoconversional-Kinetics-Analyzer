"""
kinetics.py
===========
Implementation of six isoconversional methods used to compute the
activation energy Ea as a function of conversion (alpha) from
non-isothermal kinetic data measured at several heating rates.

Implemented methods
--------------------
* Friedman (differential)
* Flynn-Wall-Ozawa (FWO)
* Kissinger-Akahira-Sunose (KAS)
* Starink
* Vyazovkin (advanced, iterative / non-linear)
* KTH (original method; discretised-Arrhenius differential approach)

Only NumPy and pandas are used (no SciPy), per the project's dependency
constraints. The Vyazovkin method implements its own temperature
integral (trapezoidal rule) and its own 1-D minimiser (golden-section
search), since ``scipy.optimize`` is not available.

All public functions return a ``dict`` mapping ``alpha -> Ea_kJ_per_mol``
(NaN for points where the calculation could not be performed).
"""

from __future__ import annotations

import logging
from typing import Dict, List, Sequence

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)

#: Universal gas constant, J / (mol K)
R = 8.314

#: Column names (temperature) in the order matching the beta list.
_T_COLUMNS = ["T1", "T2", "T3", "T4"]


def _beta_to_kelvin_per_second(beta_list: Sequence[float]) -> List[float]:
    """Convert a list of heating rates from K/min to K/s."""
    return [b / 60.0 for b in beta_list]


def _linear_slope(x: Sequence[float], y: Sequence[float]) -> float:
    """
    Ordinary least-squares slope of y vs x using ``numpy.polyfit``.

    Returns ``numpy.nan`` if fewer than two valid (finite) points are
    available.
    """
    x_arr = np.asarray(x, dtype=float)
    y_arr = np.asarray(y, dtype=float)
    mask = np.isfinite(x_arr) & np.isfinite(y_arr)
    if mask.sum() < 2:
        return float("nan")
    slope, _intercept = np.polyfit(x_arr[mask], y_arr[mask], 1)
    return float(slope)


# --------------------------------------------------------------------------- #
# 1. Friedman method
# --------------------------------------------------------------------------- #
def friedman(df: pd.DataFrame, beta_list: Sequence[float]) -> Dict[float, float]:
    """
    Friedman differential isoconversional method.

    ``ln(beta * dalpha/dT) = ln(A * f(alpha)) - Ea / (R * T)``

    For each alpha, the four (1/T, ln(beta * dalpha/dT)) pairs (one per
    heating rate) are fit with a straight line whose slope is -Ea/R.

    Parameters
    ----------
    df : pandas.DataFrame
        Data with columns alpha, T1, T2, T3, T4 (same alpha grid for all
        heating rates -- see :func:`isokinetics.data_loader.interpolate_alpha`).
    beta_list : Sequence[float]
        The four heating rates, in K/min, in the same order as columns
        T1..T4.

    Returns
    -------
    dict
        Mapping alpha -> Ea (kJ/mol).
    """
    if len(beta_list) != 4:
        raise ValueError("Friedman method requires exactly 4 heating rates.")

    betas_ks = _beta_to_kelvin_per_second(beta_list)
    alpha = df["alpha"].to_numpy(dtype=float)

    # Pre-compute dalpha/dT for every heating rate over the whole series.
    dadT = {}
    for col in _T_COLUMNS:
        T = df[col].to_numpy(dtype=float)
        # np.gradient handles non-uniform spacing correctly.
        dadT[col] = np.gradient(alpha, T)

    results: Dict[float, float] = {}
    for i, a in enumerate(alpha):
        x_vals, y_vals = [], []
        for beta, col in zip(betas_ks, _T_COLUMNS):
            T = df[col].iloc[i]
            rate = beta * dadT[col][i]
            if T > 0 and rate > 0:
                x_vals.append(1.0 / T)
                y_vals.append(np.log(rate))
        slope = _linear_slope(x_vals, y_vals)
        results[float(a)] = -slope * R / 1000.0 if np.isfinite(slope) else float("nan")

    return results


# --------------------------------------------------------------------------- #
# 2. Flynn-Wall-Ozawa (FWO)
# --------------------------------------------------------------------------- #
def fwo(df: pd.DataFrame, beta_list: Sequence[float]) -> Dict[float, float]:
    """
    Flynn-Wall-Ozawa (FWO) integral isoconversional method.

    ``ln(beta) = const - 1.052 * Ea / (R * T)``

    Parameters
    ----------
    df : pandas.DataFrame
        Data with columns alpha, T1, T2, T3, T4.
    beta_list : Sequence[float]
        The four heating rates, in K/min.

    Returns
    -------
    dict
        Mapping alpha -> Ea (kJ/mol).
    """
    if len(beta_list) != 4:
        raise ValueError("FWO method requires exactly 4 heating rates.")

    betas_ks = _beta_to_kelvin_per_second(beta_list)
    alpha = df["alpha"].to_numpy(dtype=float)

    results: Dict[float, float] = {}
    for i, a in enumerate(alpha):
        x_vals, y_vals = [], []
        for beta, col in zip(betas_ks, _T_COLUMNS):
            T = df[col].iloc[i]
            if T > 0 and beta > 0:
                x_vals.append(1.0 / T)
                y_vals.append(np.log(beta))
        slope = _linear_slope(x_vals, y_vals)
        results[float(a)] = (
            -slope * R / 1.052 / 1000.0 if np.isfinite(slope) else float("nan")
        )

    return results


# --------------------------------------------------------------------------- #
# 3. Kissinger-Akahira-Sunose (KAS)
# --------------------------------------------------------------------------- #
def kas(df: pd.DataFrame, beta_list: Sequence[float]) -> Dict[float, float]:
    """
    Kissinger-Akahira-Sunose (KAS) integral isoconversional method.

    ``ln(beta / T^2) = const - Ea / (R * T)``

    Parameters
    ----------
    df : pandas.DataFrame
        Data with columns alpha, T1, T2, T3, T4.
    beta_list : Sequence[float]
        The four heating rates, in K/min.

    Returns
    -------
    dict
        Mapping alpha -> Ea (kJ/mol).
    """
    if len(beta_list) != 4:
        raise ValueError("KAS method requires exactly 4 heating rates.")

    betas_ks = _beta_to_kelvin_per_second(beta_list)
    alpha = df["alpha"].to_numpy(dtype=float)

    results: Dict[float, float] = {}
    for i, a in enumerate(alpha):
        x_vals, y_vals = [], []
        for beta, col in zip(betas_ks, _T_COLUMNS):
            T = df[col].iloc[i]
            if T > 0 and beta > 0:
                x_vals.append(1.0 / T)
                y_vals.append(np.log(beta / T ** 2))
        slope = _linear_slope(x_vals, y_vals)
        results[float(a)] = -slope * R / 1000.0 if np.isfinite(slope) else float("nan")

    return results


# --------------------------------------------------------------------------- #
# 4. Starink
# --------------------------------------------------------------------------- #
def starink(df: pd.DataFrame, beta_list: Sequence[float]) -> Dict[float, float]:
    """
    Starink integral isoconversional method.

    ``ln(beta / T^1.92) = const - 1.0008 * Ea / (R * T)``

    Parameters
    ----------
    df : pandas.DataFrame
        Data with columns alpha, T1, T2, T3, T4.
    beta_list : Sequence[float]
        The four heating rates, in K/min.

    Returns
    -------
    dict
        Mapping alpha -> Ea (kJ/mol).
    """
    if len(beta_list) != 4:
        raise ValueError("Starink method requires exactly 4 heating rates.")

    betas_ks = _beta_to_kelvin_per_second(beta_list)
    alpha = df["alpha"].to_numpy(dtype=float)

    results: Dict[float, float] = {}
    for i, a in enumerate(alpha):
        x_vals, y_vals = [], []
        for beta, col in zip(betas_ks, _T_COLUMNS):
            T = df[col].iloc[i]
            if T > 0 and beta > 0:
                x_vals.append(1.0 / T)
                y_vals.append(np.log(beta / T ** 1.92))
        slope = _linear_slope(x_vals, y_vals)
        results[float(a)] = (
            -slope * R / 1.0008 / 1000.0 if np.isfinite(slope) else float("nan")
        )

    return results


# --------------------------------------------------------------------------- #
# 5. Vyazovkin (advanced / iterative)
# --------------------------------------------------------------------------- #
def _temperature_integral(
    e_j_per_mol: float, T: float, T_ref: float = 300.0, n: int = 200
) -> float:
    """
    Numerically evaluate the temperature integral

    ``I(E, T) = integral_{T_ref}^{T} exp(-E / (R * T')) dT'``

    using the composite trapezoidal rule (no SciPy dependency).

    Parameters
    ----------
    e_j_per_mol : float
        Activation energy in J/mol.
    T : float
        Upper integration limit (Kelvin).
    T_ref : float, optional
        Lower integration limit (Kelvin), default 300 K.
    n : int, optional
        Number of grid points used for the trapezoidal rule.

    Returns
    -------
    float
        Value of the integral. Returns 0.0 if T <= T_ref.
    """
    if T <= T_ref:
        return 0.0
    grid = np.linspace(T_ref, T, n)
    integrand = np.exp(-e_j_per_mol / (R * grid))
    # Manual composite trapezoidal rule. Implemented by hand (rather than
    # calling numpy.trapz / numpy.trapezoid) so behaviour is identical
    # across NumPy versions, since the function was renamed/deprecated
    # between NumPy 1.x and 2.x.
    widths = np.diff(grid)
    heights = (integrand[:-1] + integrand[1:]) / 2.0
    return float(np.sum(widths * heights))


def _vyazovkin_objective(
    e_kj_per_mol: float,
    temperatures: Sequence[float],
    betas_ks: Sequence[float],
) -> float:
    """
    Vyazovkin's objective function Phi(Ea) for a single alpha value:

    ``Phi(Ea) = sum_i sum_{j != i} [I(Ea, T_i) * beta_j] / [I(Ea, T_j) * beta_i]``

    Note on the heating-rate weighting
    -----------------------------------
    The activation-energy integral ``I(E, T)`` alone (integrated from a
    fixed reference temperature up to T) grows with T regardless of E,
    so a "naive" ratio ``I(Ea, T_i) / I(Ea, T_j)`` without the
    ``beta_j / beta_i`` weighting factor is dominated by whichever
    heating rate has the largest T at that alpha, and the resulting
    objective function has no interior minimum (it is minimised as
    ``Ea -> 0``, which is not physically meaningful). Including the
    heating-rate ratio -- as in Vyazovkin's original formulation
    (S. Vyazovkin, J. Comput. Chem. 18 (1997) 393) -- correctly balances
    the comparison across heating rates and yields a well-defined
    interior minimum near the physically correct activation energy.
    This was verified numerically against the sample dataset before
    being adopted here.

    Parameters
    ----------
    e_kj_per_mol : float
        Candidate activation energy, in kJ/mol.
    temperatures : Sequence[float]
        Temperatures (K) at the given alpha, one per heating rate.
    betas_ks : Sequence[float]
        Heating rates (K/s), in the same order as ``temperatures``.

    Returns
    -------
    float
        Value of the objective function (the true minimum is achieved
        near the correct activation energy). Returns ``inf`` if any
        integral evaluates to zero or a negative number (degenerate).
    """
    e_j = e_kj_per_mol * 1000.0
    integrals = [_temperature_integral(e_j, T) for T in temperatures]

    if any(i <= 0 for i in integrals):
        return float("inf")

    total = 0.0
    n = len(integrals)
    for i in range(n):
        for j in range(n):
            if i == j:
                continue
            total += (integrals[i] * betas_ks[j]) / (integrals[j] * betas_ks[i])
    return total


def _golden_section_search(
    func, low: float, high: float, tol: float = 0.1, max_iter: int = 200
) -> float:
    """
    Minimise a strictly-unimodal scalar function on ``[low, high]`` using
    a golden-section search (SciPy-free replacement for
    ``scipy.optimize.minimize_scalar``).

    Parameters
    ----------
    func : Callable[[float], float]
        The (assumed unimodal) function to minimise.
    low, high : float
        Bracket in which to search.
    tol : float, optional
        Stop once the bracket width is below this tolerance.
    max_iter : int, optional
        Safety cap on the number of iterations.

    Returns
    -------
    float
        The value of x that (approximately) minimises ``func``.
    """
    invphi = (np.sqrt(5.0) - 1.0) / 2.0  # ~0.618

    a, b = float(low), float(high)
    c = b - invphi * (b - a)
    d = a + invphi * (b - a)
    fc, fd = func(c), func(d)

    for _ in range(max_iter):
        if abs(b - a) < tol:
            break
        if fc < fd:
            b, d, fd = d, c, fc
            c = b - invphi * (b - a)
            fc = func(c)
        else:
            a, c, fc = c, d, fd
            d = a + invphi * (b - a)
            fd = func(d)

    return (a + b) / 2.0


def vyazovkin(
    df: pd.DataFrame,
    beta_list: Sequence[float],
    e_min: float = 30.0,
    e_max: float = 500.0,
    tol: float = 0.1,
) -> Dict[float, float]:
    """
    Vyazovkin's advanced (non-linear, integral) isoconversional method.

    For every alpha, the activation energy is the value that minimises
    the objective function

    ``Phi(Ea) = sum_i sum_{j != i} I(Ea, T_i) / I(Ea, T_j)``

    where ``I(E, T)`` is the temperature integral evaluated by the
    trapezoidal rule. The minimisation itself is performed with a
    golden-section search, since this project deliberately avoids a
    SciPy dependency.

    Parameters
    ----------
    df : pandas.DataFrame
        Data with columns alpha, T1, T2, T3, T4.
    beta_list : Sequence[float]
        The four heating rates, in K/min (not used directly by this
        method's objective function, but kept for a consistent API and
        for potential future refinements).
    e_min, e_max : float, optional
        Search bracket for the activation energy, in kJ/mol.
    tol : float, optional
        Convergence tolerance for the golden-section search, in kJ/mol.

    Returns
    -------
    dict
        Mapping alpha -> Ea (kJ/mol).
    """
    if len(beta_list) != 4:
        raise ValueError("Vyazovkin method requires exactly 4 heating rates.")

    betas_ks = _beta_to_kelvin_per_second(beta_list)
    alpha = df["alpha"].to_numpy(dtype=float)
    results: Dict[float, float] = {}

    for i, a in enumerate(alpha):
        temperatures = [df[col].iloc[i] for col in _T_COLUMNS]
        try:
            ea = _golden_section_search(
                lambda e: _vyazovkin_objective(e, temperatures, betas_ks),
                e_min,
                e_max,
                tol=tol,
            )
            results[float(a)] = float(ea)
        except Exception:  # noqa: BLE001 - keep other alphas usable on failure
            results[float(a)] = float("nan")

    return results


# --------------------------------------------------------------------------- #
# 6. KTH (Kadri-Trache-Hassam) -- discretised-Arrhenius differential method
# --------------------------------------------------------------------------- #
def _kth_regression(
    df: pd.DataFrame, beta_list: Sequence[float]
) -> "tuple[Dict[float, float], Dict[float, float]]":
    """
    Shared regression core for :func:`kth` and :func:`kth_full`.

    For each alpha step, regresses ``ln(rate)`` against ``1/T_mean``
    across heating rates (see :func:`kth` for the full derivation) and
    returns *both* results of that regression:

    * the slope, converted to an activation energy Ea(alpha) (kJ/mol);
    * the intercept, converted to ``Phi(alpha) = exp(intercept) =
      A(alpha) * f(alpha)`` (s^-1) -- the product of the pre-exponential
      factor and the (still unknown, at this stage) reaction model.

    :func:`kth` only exposes the first of these (to stay drop-in
    compatible with the other methods in this module); :func:`kth_full`
    uses both, plus a Malek-method model identification step, to also
    recover A(alpha) and f(alpha).

    Parameters
    ----------
    df : pandas.DataFrame
        Data with columns alpha, T1, T2, T3, T4.
    beta_list : Sequence[float]
        The four heating rates, in K/min.

    Returns
    -------
    tuple of dict
        ``(ea_kj_per_mol, phi_per_second)``, both mapping alpha -> value
        (NaN where fewer than 3 valid heating-rate pairs were available).
    """
    if len(beta_list) != 4:
        raise ValueError("KTH method requires exactly 4 heating rates.")

    betas_ks = _beta_to_kelvin_per_second(beta_list)
    alpha = df["alpha"].to_numpy(dtype=float)
    n = len(alpha)

    logger.debug("KTH: starting computation for %d alpha points, betas=%s", n, beta_list)

    ea_results: Dict[float, float] = {}
    phi_results: Dict[float, float] = {}
    n_skipped = 0

    for i in range(n):
        # Step to the right for every point except the last, which has
        # no "next" point -- step to the left instead.
        if i < n - 1:
            i0, i1 = i, i + 1
        else:
            i0, i1 = i - 1, i

        d_alpha = alpha[i1] - alpha[i0]

        x_vals, y_vals = [], []
        for beta, col in zip(betas_ks, _T_COLUMNS):
            T0 = df[col].iloc[i0]
            T1 = df[col].iloc[i1]
            d_t = (T1 - T0) / beta
            T_mean = (T0 + T1) / 2.0

            if d_t > 0 and T_mean > 0 and d_alpha > 0:
                rate = d_alpha / d_t
                if rate > 0:
                    x_vals.append(1.0 / T_mean)
                    y_vals.append(np.log(rate))

        # Per the method's validation requirements: at least 3 valid
        # (heating rate, temperature) pairs are required for a
        # meaningful regression; fewer than that yields NaN rather than
        # an unreliable fit.
        if len(x_vals) < 3:
            n_skipped += 1
            logger.debug(
                "KTH: alpha=%.4f has only %d valid heating-rate pairs "
                "(need >= 3); returning NaN.",
                alpha[i],
                len(x_vals),
            )
            ea_results[float(alpha[i])] = float("nan")
            phi_results[float(alpha[i])] = float("nan")
            continue

        x_arr = np.asarray(x_vals, dtype=float)
        y_arr = np.asarray(y_vals, dtype=float)
        slope, intercept = np.polyfit(x_arr, y_arr, 1)

        ea_results[float(alpha[i])] = (
            -slope * R / 1000.0 if np.isfinite(slope) else float("nan")
        )
        phi_results[float(alpha[i])] = (
            float(np.exp(intercept)) if np.isfinite(intercept) else float("nan")
        )

    if n_skipped:
        logger.debug("KTH: %d/%d alpha points returned NaN.", n_skipped, n)
    logger.debug("KTH: finished, average Ea = %.2f kJ/mol", average_ea(ea_results))

    return ea_results, phi_results


def kth(df: pd.DataFrame, beta_list: Sequence[float]) -> Dict[float, float]:
    """
    KTH method: an original isoconversional approach based on a
    discretised form of the Arrhenius equation.

    ``alpha_{i+1} = alpha_i + Phi(alpha_i) * exp(-Ea_i / (R*T_mean,i)) * dt_i``

    Taking the natural logarithm linearises this to::

        ln((alpha_{i+1} - alpha_i) / dt_i) = ln(Phi(alpha_i)) - Ea_i / (R * T_mean,i)

    i.e. ``Y = a*X + b`` with ``Y = ln(rate)``, ``X = 1/T_mean``, and
    slope ``a = -Ea/R``. Where this differs from :func:`friedman`:

    * The reaction rate is estimated as a **discrete step** rate,
      ``(alpha_{i+1} - alpha_i) / dt_i``, over the interval between two
      consecutive grid points on the alpha axis, rather than an
      instantaneous derivative ``dalpha/dT`` at a single point.
    * It is paired with the **mean temperature over that same interval**,
      ``T_mean,i = (T_i + T_{i+1}) / 2``, rather than the temperature at
      a single endpoint.
    * The time step is recovered from the temperature step under the
      linear-heating assumption ``T = T0 + beta*t``, i.e.
      ``dt_i = (T_{i+1} - T_i) / beta`` -- no explicit time column is
      required in the input data.

    As with the other methods here, every heating rate contributes one
    ``(1/T_mean, ln(rate))`` pair for a given alpha step, and a linear
    regression across those points (one per heating rate) gives the
    slope ``-Ea/R``.

    Parameters
    ----------
    df : pandas.DataFrame
        Data with columns alpha, T1, T2, T3, T4 (same alpha grid for all
        heating rates -- see
        :func:`isokinetics.data_loader.interpolate_alpha`).
    beta_list : Sequence[float]
        The four heating rates, in K/min, in the same order as columns
        T1..T4.

    Returns
    -------
    dict
        Mapping alpha -> Ea (kJ/mol). Every alpha in ``df`` is present:
        each point uses the discrete step to its right (alpha_i to
        alpha_{i+1}) to estimate its rate, except the last point, which
        uses the step to its left (alpha_{i-1} to alpha_i) since there
        is no "next" point to step to.

    Notes
    -----
    This returns only Ea(alpha), so it is drop-in compatible with the
    other methods in this module (all consumed the same way by the
    GUI/plotting/export pipeline, which expects a single ``{alpha: Ea}``
    mapping per method). For the full kinetic triplet -- also recovering
    the pre-exponential factor A(alpha) and the experimental reaction
    model f(alpha) via Malek's method -- see :func:`kth_full`.
    """
    ea_results, _phi_results = _kth_regression(df, beta_list)
    return ea_results


# --------------------------------------------------------------------------- #
# 6b. KTH full triplet: Ea(alpha), A(alpha), f(alpha) via Malek's method
# --------------------------------------------------------------------------- #

#: Candidate theoretical solid-state reaction models used for Malek-method
#: model identification (a standard subset of Table IV.1 in the thesis,
#: covering the four classical mechanistic families). Each entry maps a
#: model code to (f(alpha), g(alpha)) -- the differential and integral
#: forms of the reaction model, respectively.
KTH_CANDIDATE_MODELS: List[str] = [
    "F0", "F1", "F2", "F3",   # reaction order
    "R2", "R3",               # geometric contraction (contracting area/volume)
    "D1", "D2", "D3", "D4",   # diffusion
    "A2", "A3", "A4",         # Avrami-Erofeev (nucleation and growth)
]

#: Human-readable descriptions, purely for display in the GUI/exports.
KTH_MODEL_DESCRIPTIONS: Dict[str, str] = {
    "F0": "Zero-order reaction",
    "F1": "First-order reaction",
    "F2": "Second-order reaction",
    "F3": "Third-order reaction",
    "R2": "Contracting area (geometric contraction)",
    "R3": "Contracting volume (geometric contraction)",
    "D1": "One-dimensional diffusion",
    "D2": "Two-dimensional diffusion (Valensi)",
    "D3": "Three-dimensional diffusion (Jander)",
    "D4": "Three-dimensional diffusion (Ginstling-Brounshtein)",
    "A2": "Avrami-Erofeev, n=2 (nucleation and growth)",
    "A3": "Avrami-Erofeev, n=3 (nucleation and growth)",
    "A4": "Avrami-Erofeev, n=4 (nucleation and growth)",
}


def _model_f_g(name: str, alpha: np.ndarray) -> "tuple[np.ndarray, np.ndarray]":
    """
    Evaluate a named theoretical solid-state reaction model's
    differential and integral forms, f(alpha) and g(alpha), over an
    array of alpha values.

    This is a standard subset of the classical solid-state kinetic
    models (reaction-order Fn, geometric-contraction Rn, diffusion Dn,
    and Avrami-Erofeev nucleation-and-growth An), corresponding to the
    same four mechanistic families as Table IV.1 in the thesis.

    Parameters
    ----------
    name : str
        One of :data:`KTH_CANDIDATE_MODELS`.
    alpha : numpy.ndarray
        Conversion values, clipped away from the 0/1 boundaries
        internally to avoid singularities (several models have f(alpha)
        or g(alpha) diverge at alpha=0 or alpha=1).

    Returns
    -------
    tuple of numpy.ndarray
        ``(f_alpha, g_alpha)``, each the same shape as ``alpha``.

    Raises
    ------
    ValueError
        If ``name`` is not a recognised model code.
    """
    a = np.clip(np.asarray(alpha, dtype=float), 1e-6, 1.0 - 1e-6)

    if name == "F0":
        f = np.ones_like(a)
        g = a
    elif name == "F1":
        f = 1.0 - a
        g = -np.log(1.0 - a)
    elif name == "F2":
        f = (1.0 - a) ** 2
        g = (1.0 / (1.0 - a)) - 1.0
    elif name == "F3":
        f = (1.0 - a) ** 3
        g = 0.5 * ((1.0 / (1.0 - a)) ** 2 - 1.0)
    elif name == "R2":
        f = 2.0 * (1.0 - a) ** 0.5
        g = 1.0 - (1.0 - a) ** 0.5
    elif name == "R3":
        f = 3.0 * (1.0 - a) ** (2.0 / 3.0)
        g = 1.0 - (1.0 - a) ** (1.0 / 3.0)
    elif name == "D1":
        f = 1.0 / (2.0 * a)
        g = a ** 2
    elif name == "D2":
        f = 1.0 / (-np.log(1.0 - a))
        g = (1.0 - a) * np.log(1.0 - a) + a
    elif name == "D3":
        f = 1.5 * (1.0 - a) ** (2.0 / 3.0) / (1.0 - (1.0 - a) ** (1.0 / 3.0))
        g = (1.0 - (1.0 - a) ** (1.0 / 3.0)) ** 2
    elif name == "D4":
        f = 1.5 / ((1.0 - a) ** (-1.0 / 3.0) - 1.0)
        g = 1.0 - (2.0 * a / 3.0) - (1.0 - a) ** (2.0 / 3.0)
    elif name == "A2":
        f = 2.0 * (1.0 - a) * (-np.log(1.0 - a)) ** 0.5
        g = (-np.log(1.0 - a)) ** 0.5
    elif name == "A3":
        f = 3.0 * (1.0 - a) * (-np.log(1.0 - a)) ** (2.0 / 3.0)
        g = (-np.log(1.0 - a)) ** (1.0 / 3.0)
    elif name == "A4":
        f = 4.0 * (1.0 - a) * (-np.log(1.0 - a)) ** (3.0 / 4.0)
        g = (-np.log(1.0 - a)) ** (1.0 / 4.0)
    else:
        raise ValueError(f"Unknown KTH candidate model: {name!r}")

    return f, g


def _normalize_01(values: np.ndarray) -> np.ndarray:
    """
    Min-max normalise an array to the range [0, 1] (matching the
    thesis's instruction that y(alpha) and z(alpha) be "normalisees
    entre 0 et 1"), ignoring NaNs when computing the min/max.

    Returns an all-zero array (same shape) if the input is constant or
    has no finite values, rather than dividing by zero.
    """
    values = np.asarray(values, dtype=float)
    finite = values[np.isfinite(values)]
    if finite.size == 0:
        return np.full_like(values, np.nan)
    vmin, vmax = float(finite.min()), float(finite.max())
    if vmax - vmin < 1e-300:
        return np.zeros_like(values)
    return (values - vmin) / (vmax - vmin)


def _temperature_integral_p(x: np.ndarray, span: float = 60.0, n: int = 2000) -> np.ndarray:
    """
    Numerically evaluate the temperature integral
    ``p(x) = integral_x^inf (e^-u / u^2) du`` for each value in ``x``,
    using the composite trapezoidal rule (no SciPy dependency) over a
    finite window ``[x, x + span]``.

    Why not the closed-form Senum-Yang rational approximation?
    ------------------------------------------------------------
    A commonly-cited form of this approximation is::

        p(x) ~ [(x^3 + 18x^2 + 88x + 96) / (x^4 + 20x^3 + 120x^2 + 240x + 120)] * exp(-x) / x

    Note the trailing ``exp(-x)/x`` (not ``exp(-x)/x^2``): the correct
    asymptotic behaviour of ``p(x)`` for large ``x`` is ``~ exp(-x)/x^2``,
    and the rational prefactor above already contributes a factor of
    ``1/x`` as ``x -> infinity`` (since it tends to ``x^3/x^4 = 1/x``),
    so multiplying by ``exp(-x)/x`` gives the correct ``exp(-x)/x^2``
    overall. A version with an extra ``/x`` (i.e. ``exp(-x)/x^2``
    tacked on directly) -- which is how this formula is sometimes
    mis-transcribed -- is off by a full factor of ``x`` and was found,
    during development, to make Malek-method model identification
    fail on synthetic data with a known ground-truth model. Numerical
    integration sidesteps this ambiguity entirely and was verified here
    against the exact closed form (``p(x) = e^-x/x - E1(x)``, via
    ``scipy.special.exp1``, sandbox-only/development-time check -- not
    a runtime dependency) to better than 1e-5 relative error across
    x in [5, 40], which comfortably covers the x = Ea/(RT) values seen
    in practice.

    Parameters
    ----------
    x : numpy.ndarray
        Values of x = Ea/(R*T) at which to evaluate p(x). Must be
        strictly positive.
    span : float, optional
        Integration window width (default 60, i.e. integrate from x to
        x+60). The integrand decays as exp(-u), so 60 "e-foldings" is
        far more than enough for the values of x encountered here.
    n : int, optional
        Number of grid points used per evaluation for the trapezoidal
        rule.

    Returns
    -------
    numpy.ndarray
        p(x), same shape as the input.
    """
    x = np.atleast_1d(np.asarray(x, dtype=float))
    out = np.full_like(x, np.nan)
    for i, xi in enumerate(x):
        if not np.isfinite(xi) or xi <= 0:
            continue
        u = np.linspace(xi, xi + span, n)
        integrand = np.exp(-u) / u ** 2
        widths = np.diff(u)
        heights = (integrand[:-1] + integrand[1:]) / 2.0
        out[i] = np.sum(widths * heights)
    return out


def _malek_y_z_curves(
    df: pd.DataFrame, beta_list: Sequence[float], ea_kj_per_mol: float
) -> "tuple[np.ndarray, np.ndarray]":
    """
    Compute Malek's y(alpha) and z(alpha) diagnostic functions from the
    experimental data, averaged across all heating rates (each
    heating rate's curve is normalised to [0, 1] individually before
    averaging, so no single heating rate dominates the result).

    ``y(alpha) = (dalpha/dt) * exp(Ea / (R*T))``
    ``z(alpha) = (dalpha/dt) * (T/beta) * x * exp(x) * p(x)``, ``x = Ea/(R*T)``

    The z(alpha) form used here is derived from first principles (see
    the module-level notes in :func:`kth_full`) to be *exactly*
    proportional to the theoretical ``f(alpha)*g(alpha)`` combined
    master-plot function -- this was verified numerically against
    synthetic ground-truth data during development (a version without
    the ``x*exp(x)`` factor, closer to a literal reading of the
    thesis's stated equation, was found to misidentify the reaction
    model on synthetic F1 data and was rejected).

    Parameters
    ----------
    df : pandas.DataFrame
        Data with columns alpha, T1, T2, T3, T4.
    beta_list : Sequence[float]
        The four heating rates, in K/min.
    ea_kj_per_mol : float
        A single representative activation energy (typically the
        average of :func:`kth`'s Ea(alpha) over the identification
        window) used to evaluate x = Ea/(RT) -- Malek's method assumes
        Ea is approximately constant over that window.

    Returns
    -------
    tuple of numpy.ndarray
        ``(y_alpha, z_alpha)``, each normalised to [0, 1] and the same
        length as ``df``.
    """
    betas_ks = _beta_to_kelvin_per_second(beta_list)
    alpha = df["alpha"].to_numpy(dtype=float)
    ea_j = ea_kj_per_mol * 1000.0

    y_curves = []
    z_curves = []
    for beta, col in zip(betas_ks, _T_COLUMNS):
        T = df[col].to_numpy(dtype=float)
        dadT = np.gradient(alpha, T)
        dadt = beta * dadT

        x = ea_j / (R * T)
        y = dadt * np.exp(x)

        p = _temperature_integral_p(x)
        z = dadT * T * x * np.exp(x) * p

        y_curves.append(_normalize_01(y))
        z_curves.append(_normalize_01(z))

    y_exp = _normalize_01(np.nanmean(np.vstack(y_curves), axis=0))
    z_exp = _normalize_01(np.nanmean(np.vstack(z_curves), axis=0))
    return y_exp, z_exp


def _identify_model(
    alpha: np.ndarray,
    y_exp: np.ndarray,
    z_exp: np.ndarray,
    identification_window: "tuple[float, float]" = (0.2, 0.8),
    ambiguity_score_threshold: float = 0.30,
    ambiguity_margin_ratio: float = 1.15,
) -> "tuple[str, Dict[str, float]]":
    """
    Identify the best-matching theoretical reaction model by comparing
    the experimental y(alpha)/z(alpha) curves against every candidate
    model's theoretical f(alpha) and f(alpha)*g(alpha) curves (each
    normalised to [0, 1] the same way), restricted to the alpha window
    where Malek's method is valid (Ea approximately constant -- the
    thesis states this should hold for a variation under ~10% within
    alpha in [0.2, 0.8]).

    The match score for each candidate is the sum of the RMSE between
    the experimental and theoretical curves for both y and z; the model
    with the lowest score wins.

    Parameters
    ----------
    alpha : numpy.ndarray
        Conversion grid.
    y_exp, z_exp : numpy.ndarray
        Experimental, normalised Malek diagnostic curves (see
        :func:`_malek_y_z_curves`).
    identification_window : tuple of float, optional
        Restrict scoring to this alpha range (default (0.2, 0.8), per
        the thesis's stated validity range for Malek's method).
    ambiguity_score_threshold : float, optional
        If the best score exceeds this, identification is considered
        too poor to trust and ``'unknown'`` is returned.
    ambiguity_margin_ratio : float, optional
        If the second-best score is less than this ratio times the
        best score (i.e. the two best candidates are nearly tied),
        identification is considered ambiguous and ``'unknown'`` is
        returned instead of an arbitrary tie-break.

    Returns
    -------
    tuple
        ``(model_name, scores)`` where ``model_name`` is a code from
        :data:`KTH_CANDIDATE_MODELS` or ``'unknown'``, and ``scores`` is
        a dict mapping every candidate model to its match score (lower
        is better; useful for diagnostics/plotting).
    """
    lo, hi = identification_window
    mask = (alpha >= lo) & (alpha <= hi)
    if mask.sum() < 3:
        # Identification window too narrow for this data -- fall back
        # to using every available point rather than failing outright.
        mask = np.ones_like(alpha, dtype=bool)

    scores: Dict[str, float] = {}
    for name in KTH_CANDIDATE_MODELS:
        f_th, g_th = _model_f_g(name, alpha)
        f_th_n = _normalize_01(f_th)
        fg_th_n = _normalize_01(f_th * g_th)

        valid = (
            mask
            & np.isfinite(y_exp)
            & np.isfinite(z_exp)
            & np.isfinite(f_th_n)
            & np.isfinite(fg_th_n)
        )
        if valid.sum() < 3:
            continue

        rmse_y = float(np.sqrt(np.mean((y_exp[valid] - f_th_n[valid]) ** 2)))
        rmse_z = float(np.sqrt(np.mean((z_exp[valid] - fg_th_n[valid]) ** 2)))
        score = rmse_y + rmse_z
        if np.isfinite(score):
            scores[name] = score
            logger.debug("KTH full: candidate model=%s score=%.4f", name, score)

    finite_scores = {k: v for k, v in scores.items() if np.isfinite(v)}
    if not finite_scores:
        logger.debug("KTH full: no candidate model could be scored; model=unknown.")
        return "unknown", scores

    ranked = sorted(finite_scores.items(), key=lambda kv: kv[1])
    best_name, best_score = ranked[0]

    if best_score > ambiguity_score_threshold:
        logger.debug(
            "KTH full: best model=%s score=%.4f exceeds ambiguity threshold "
            "%.2f; model=unknown.",
            best_name,
            best_score,
            ambiguity_score_threshold,
        )
        return "unknown", scores

    if len(ranked) > 1:
        second_score = ranked[1][1]
        if second_score < ambiguity_margin_ratio * best_score:
            logger.debug(
                "KTH full: best model=%s (score=%.4f) and second-best %s "
                "(score=%.4f) are too close to distinguish; model=unknown.",
                best_name,
                best_score,
                ranked[1][0],
                second_score,
            )
            return "unknown", scores

    logger.debug("KTH full: identified model=%s (score=%.4f).", best_name, best_score)
    return best_name, scores


def kth_full(
    df: pd.DataFrame,
    beta_list: Sequence[float],
    identification_window: "tuple[float, float]" = (0.2, 0.8),
) -> Dict[str, object]:
    """
    Full KTH kinetic triplet: activation energy Ea(alpha), identified
    reaction model f(alpha), and pre-exponential factor A(alpha), using
    Malek's method for the model-identification step (thesis, Chapter
    VII, section VII.4.1.3).

    Procedure
    ---------
    1. Run the same regression as :func:`kth` to get Ea(alpha) and
       ``Phi(alpha) = A(alpha)*f(alpha)``.
    2. Compute Malek's y(alpha) and z(alpha) diagnostic curves from the
       experimental data (:func:`_malek_y_z_curves`), using the average
       Ea over the identification window as a single representative
       activation energy (Malek's method assumes Ea is approximately
       constant there).
    3. Compare the experimental curves against every candidate
       theoretical model's f(alpha) and f(alpha)*g(alpha) curves
       (:func:`_identify_model`); the best match (if any is good enough
       and unambiguous) identifies the reaction model.
    4. If a model was identified, compute its theoretical f(alpha) over
       the full alpha range and recover ``A(alpha) = Phi(alpha) /
       f(alpha)``.

    Parameters
    ----------
    df : pandas.DataFrame
        Data with columns alpha, T1, T2, T3, T4.
    beta_list : Sequence[float]
        The four heating rates, in K/min.
    identification_window : tuple of float, optional
        Alpha range used for the model-identification step (default
        (0.2, 0.8), matching the thesis's stated validity range).

    Returns
    -------
    dict
        ``{"Ea": {alpha: kJ/mol}, "A": {alpha: s^-1}, "f_alpha":
        {alpha: value}, "model": model_code_or_'unknown', "model_scores":
        {model_code: score}, "y_alpha": {alpha: value}, "z_alpha":
        {alpha: value}, "y_theory": {alpha: value}, "z_theory":
        {alpha: value}}``. ``y_theory``/``z_theory`` are the identified
        model's own normalised curves (for overlaying against
        ``y_alpha``/``z_alpha`` on a diagnostic plot). When no model
        could be confidently identified, ``"model"`` is ``"unknown"``
        and ``"A"``, ``"f_alpha"``, ``"y_theory"``, and ``"z_theory"``
        are all filled with NaN (Ea, y_alpha, and z_alpha are always
        populated regardless).
    """
    ea_results, phi_results = _kth_regression(df, beta_list)
    alpha = df["alpha"].to_numpy(dtype=float)

    lo, hi = identification_window
    window_eas = [
        e for a, e in ea_results.items() if np.isfinite(e) and lo <= a <= hi
    ]
    ea_avg = float(np.mean(window_eas)) if window_eas else average_ea(ea_results)

    if not np.isfinite(ea_avg):
        logger.debug("KTH full: no finite Ea available; cannot run Malek identification.")
        nan_map = {float(a): float("nan") for a in alpha}
        return {
            "Ea": ea_results,
            "A": dict(nan_map),
            "f_alpha": dict(nan_map),
            "model": "unknown",
            "model_scores": {},
            "y_alpha": dict(nan_map),
            "z_alpha": dict(nan_map),
            "y_theory": dict(nan_map),
            "z_theory": dict(nan_map),
        }

    y_exp, z_exp = _malek_y_z_curves(df, beta_list, ea_avg)
    model_name, scores = _identify_model(alpha, y_exp, z_exp, identification_window)

    if model_name != "unknown":
        f_theory, g_theory = _model_f_g(model_name, alpha)
        f_alpha_dict = {float(a): float(fv) for a, fv in zip(alpha, f_theory)}
        A_dict: Dict[float, float] = {}
        for a, fv in zip(alpha, f_theory):
            a_key = float(a)
            phi_v = phi_results.get(a_key, float("nan"))
            A_dict[a_key] = (
                phi_v / fv if (np.isfinite(phi_v) and fv > 0) else float("nan")
            )
        y_theory_n = _normalize_01(f_theory)
        z_theory_n = _normalize_01(f_theory * g_theory)
        y_theory_dict = {float(a): float(v) for a, v in zip(alpha, y_theory_n)}
        z_theory_dict = {float(a): float(v) for a, v in zip(alpha, z_theory_n)}
    else:
        f_alpha_dict = {float(a): float("nan") for a in alpha}
        A_dict = {float(a): float("nan") for a in alpha}
        y_theory_dict = {float(a): float("nan") for a in alpha}
        z_theory_dict = {float(a): float("nan") for a in alpha}

    return {
        "Ea": ea_results,
        "A": A_dict,
        "f_alpha": f_alpha_dict,
        "model": model_name,
        "model_scores": scores,
        "y_alpha": {float(a): float(v) for a, v in zip(alpha, y_exp)},
        "z_alpha": {float(a): float(v) for a, v in zip(alpha, z_exp)},
        "y_theory": y_theory_dict,
        "z_theory": z_theory_dict,
    }


#: Registry mapping a human-readable method name to its implementation.
#: Used by the GUI to iterate over the methods the user has selected.
METHODS = {
    "Friedman": friedman,
    "FWO": fwo,
    "KAS": kas,
    "Starink": starink,
    "Vyazovkin": vyazovkin,
    "KTH": kth,
}


def average_ea(results: Dict[float, float]) -> float:
    """
    Compute the mean activation energy over all alpha values, ignoring
    NaNs.

    Parameters
    ----------
    results : dict
        Mapping alpha -> Ea (kJ/mol), as returned by any method above.

    Returns
    -------
    float
        Mean Ea in kJ/mol, or ``numpy.nan`` if no finite values exist.
    """
    values = np.array(list(results.values()), dtype=float)
    finite = values[np.isfinite(values)]
    if finite.size == 0:
        return float("nan")
    return float(np.mean(finite))
